/**
 * Transaction-Autopilot — Canvas & SVG Charting Module
 * Zero-dependency, accessible, high-DPI retina charts for volume velocity and health distribution
 */

import { formatCurrency } from './utils.js';

/**
 * Render High-DPI 24-Hour Transaction Volume Area Chart
 */
export function renderVolumeChart(canvasId, dataPoints = null) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();

  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  ctx.scale(dpr, dpr);

  const width = rect.width;
  const height = rect.height;

  // Default illustrative 24h hourly distribution
  const points = dataPoints || [
    { label: '00:00', value: 3400 },
    { label: '04:00', value: 2100 },
    { label: '08:00', value: 6800 },
    { label: '12:00', value: 12400 },
    { label: '16:00', value: 9200 },
    { label: '20:00', value: 8500 },
    { label: '23:59', value: 7100 }
  ];

  ctx.clearRect(0, 0, width, height);

  const padLeft = 45;
  const padBottom = 28;
  const padTop = 15;
  const padRight = 15;

  const plotWidth = width - padLeft - padRight;
  const plotHeight = height - padTop - padBottom;

  const maxVal = Math.max(...points.map(p => p.value)) * 1.15;
  const minVal = 0;

  // Grid lines
  ctx.strokeStyle = '#E2E8F0';
  ctx.lineWidth = 1;
  ctx.setLineDash([4, 4]);

  const gridSteps = 4;
  ctx.font = '11px Inter, sans-serif';
  ctx.fillStyle = '#94A3B8';
  ctx.textAlign = 'right';

  for (let i = 0; i <= gridSteps; i++) {
    const yVal = minVal + (maxVal - minVal) * (i / gridSteps);
    const yPos = padTop + plotHeight - (plotHeight * (i / gridSteps));

    ctx.beginPath();
    ctx.moveTo(padLeft, yPos);
    ctx.lineTo(width - padRight, yPos);
    ctx.stroke();

    ctx.fillText(`$${(yVal / 1000).toFixed(0)}k`, padLeft - 8, yPos + 4);
  }

  ctx.setLineDash([]); // reset line dash

  // Calculate coordinates
  const coords = points.map((p, idx) => {
    const x = padLeft + (plotWidth / (points.length - 1)) * idx;
    const y = padTop + plotHeight - ((p.value - minVal) / (maxVal - minVal)) * plotHeight;
    return { x, y, label: p.label, value: p.value };
  });

  // Draw Area Gradient
  const gradient = ctx.createLinearGradient(0, padTop, 0, padTop + plotHeight);
  gradient.addColorStop(0, 'rgba(0, 112, 224, 0.22)');
  gradient.addColorStop(1, 'rgba(0, 112, 224, 0.00)');

  ctx.beginPath();
  ctx.moveTo(coords[0].x, padTop + plotHeight);
  coords.forEach((c, idx) => {
    if (idx === 0) {
      ctx.lineTo(c.x, c.y);
    } else {
      const prev = coords[idx - 1];
      const cx = (prev.x + c.x) / 2;
      ctx.bezierCurveTo(cx, prev.y, cx, c.y, c.x, c.y);
    }
  });
  ctx.lineTo(coords[coords.length - 1].x, padTop + plotHeight);
  ctx.closePath();
  ctx.fillStyle = gradient;
  ctx.fill();

  // Draw Stroke Line
  ctx.beginPath();
  coords.forEach((c, idx) => {
    if (idx === 0) {
      ctx.moveTo(c.x, c.y);
    } else {
      const prev = coords[idx - 1];
      const cx = (prev.x + c.x) / 2;
      ctx.bezierCurveTo(cx, prev.y, cx, c.y, c.x, c.y);
    }
  });
  ctx.strokeStyle = '#0070E0';
  ctx.lineWidth = 2.5;
  ctx.stroke();

  // Draw Points & Labels
  ctx.textAlign = 'center';
  coords.forEach(c => {
    // Circle point
    ctx.beginPath();
    ctx.arc(c.x, c.y, 4, 0, Math.PI * 2);
    ctx.fillStyle = '#FFFFFF';
    ctx.fill();
    ctx.strokeStyle = '#0070E0';
    ctx.lineWidth = 2;
    ctx.stroke();

    // X-axis label
    ctx.fillStyle = '#64748B';
    ctx.fillText(c.label, c.x, height - 6);
  });
}

/**
 * Render Transaction Health Distribution Donut
 */
export function renderHealthDonut(containerId, metrics) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const total = metrics.totalCount || 8;
  const healthy = metrics.healthyCount || 5;
  const critical = metrics.criticalCount || 2;
  const warning = metrics.warningCount || 1;

  const healthyPct = Math.round((healthy / total) * 100);
  const criticalPct = Math.round((critical / total) * 100);
  const warningPct = 100 - healthyPct - criticalPct;

  container.innerHTML = `
    <div style="display:flex;align-items:center;gap:24px;flex-wrap:wrap;">
      <div style="position:relative;width:140px;height:140px;flex-shrink:0;">
        <svg viewBox="0 0 36 36" style="width:100%;height:100%;transform:rotate(-90deg);">
          <!-- Background track -->
          <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
            fill="none" stroke="#E2E8F0" stroke-width="3.5" />
          <!-- Healthy Arc -->
          <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
            fill="none" stroke="#15803D" stroke-width="3.8" stroke-dasharray="${healthyPct}, 100" />
          <!-- Critical Arc -->
          <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
            fill="none" stroke="#B91C1C" stroke-width="3.8"
            stroke-dasharray="${criticalPct}, 100"
            stroke-dashoffset="-${healthyPct}" />
          <!-- Warning Arc -->
          <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
            fill="none" stroke="#B45309" stroke-width="3.8"
            stroke-dasharray="${warningPct}, 100"
            stroke-dashoffset="-${healthyPct + criticalPct}" />
        </svg>
        <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;">
          <span style="font-size:20px;font-weight:700;color:#0F172A;line-height:1;" class="tabular-nums">${metrics.healthyRate}%</span>
          <span style="font-size:10px;color:#64748B;font-weight:600;text-transform:uppercase;">Healthy</span>
        </div>
      </div>

      <div style="flex:1;display:flex;flex-direction:column;gap:8px;min-width:140px;">
        <div style="display:flex;align-items:center;justify-content:space-between;font-size:12px;">
          <span style="display:flex;align-items:center;gap:6px;color:#475569;">
            <span style="width:8px;height:8px;border-radius:50%;background:#15803D;"></span>
            Synchronized
          </span>
          <strong class="tabular-nums" style="color:#0F172A;">${healthy} (${healthyPct}%)</strong>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;font-size:12px;">
          <span style="display:flex;align-items:center;gap:6px;color:#475569;">
            <span style="width:8px;height:8px;border-radius:50%;background:#B91C1C;"></span>
            Critical Discrepancy
          </span>
          <strong class="tabular-nums" style="color:#0F172A;">${critical} (${criticalPct}%)</strong>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;font-size:12px;">
          <span style="display:flex;align-items:center;gap:6px;color:#475569;">
            <span style="width:8px;height:8px;border-radius:50%;background:#B45309;"></span>
            Warning / Stalled
          </span>
          <strong class="tabular-nums" style="color:#0F172A;">${warning} (${warningPct}%)</strong>
        </div>
      </div>
    </div>
  `;
}
