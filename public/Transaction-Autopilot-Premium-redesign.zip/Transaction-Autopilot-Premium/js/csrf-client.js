/**
 * Transaction-Autopilot — Client-Side CSRF & Session Security Helper
 * Handles session bootstrapping, double-submit cookie reading, token injection,
 * and automatic token renewal on expiration.
 */

let cachedCsrfToken = null;

/**
 * Read cookie by name from document.cookie
 */
export function getCookie(name) {
  if (typeof document === 'undefined') return null;
  const match = document.cookie.match(new RegExp('(?:^|;\\s*)' + name + '=([^;]*)'));
  return match ? decodeURIComponent(match[1]) : null;
}

/**
 * Retrieve a valid CSRF token:
 * 1. From in-memory cache
 * 2. From document.cookie ('csrf_token')
 * 3. Via GET /api/auth/session bootstrap
 */
export async function getCsrfToken(forceRefresh = false) {
  if (!forceRefresh) {
    if (cachedCsrfToken) return cachedCsrfToken;
    const cookieToken = getCookie('csrf_token');
    if (cookieToken) {
      cachedCsrfToken = cookieToken;
      return cookieToken;
    }
  }

  try {
    const res = await fetch('/api/auth/session', {
      method: 'GET',
      credentials: 'include'
    });
    if (res.ok) {
      const data = await res.json().catch(() => null);
      if (data?.csrfToken) {
        cachedCsrfToken = data.csrfToken;
        return data.csrfToken;
      }
    }
  } catch (err) {
    console.warn('[CSRF] Could not bootstrap token from /api/auth/session:', err.message);
  }

  // Fallback to cookie
  cachedCsrfToken = getCookie('csrf_token') || null;
  return cachedCsrfToken;
}

/**
 * Execute state-mutating fetch with automatic CSRF token inclusion and retry on CSRF expiry
 */
export async function fetchWithCsrf(url, options = {}) {
  const method = (options.method || 'GET').toUpperCase();
  const opts = { ...options };
  opts.credentials = opts.credentials || 'include';

  // State-mutating methods require CSRF token
  if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(method)) {
    const token = await getCsrfToken();
    if (token) {
      if (opts.headers instanceof Headers) {
        if (!opts.headers.has('x-csrf-token')) opts.headers.set('x-csrf-token', token);
      } else if (Array.isArray(opts.headers)) {
        opts.headers.push(['x-csrf-token', token]);
      } else {
        opts.headers = opts.headers || {};
        if (!opts.headers['x-csrf-token']) opts.headers['x-csrf-token'] = token;
      }
    }
  }

  let res = await fetch(url, opts);

  // If rejected due to missing or invalid CSRF token, refresh and retry once
  if (res.status === 403) {
    const clone = res.clone();
    const data = await clone.json().catch(() => null);
    const isCsrfError = data?.error && /csrf/i.test(data.error);

    if (isCsrfError) {
      console.warn('[CSRF] Received 403 CSRF error. Re-authenticating session and retrying request...');
      const newToken = await getCsrfToken(true);
      if (newToken) {
        if (opts.headers instanceof Headers) {
          opts.headers.set('x-csrf-token', newToken);
        } else if (Array.isArray(opts.headers)) {
          const idx = opts.headers.findIndex(([k]) => k.toLowerCase() === 'x-csrf-token');
          if (idx >= 0) opts.headers[idx][1] = newToken;
          else opts.headers.push(['x-csrf-token', newToken]);
        } else {
          opts.headers = opts.headers || {};
          opts.headers['x-csrf-token'] = newToken;
        }
        res = await fetch(url, opts);
      }
    }
  }

  // Capture updated token from response header if present
  const updatedToken = res.headers?.get?.('x-csrf-token');
  if (updatedToken) {
    cachedCsrfToken = updatedToken;
  }

  return res;
}

if (typeof window !== 'undefined') {
  window.csrfClient = {
    getCsrfToken,
    fetchWithCsrf,
    getCookie
  };
}

export default {
  getCookie,
  getCsrfToken,
  fetchWithCsrf
};
