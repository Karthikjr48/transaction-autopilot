/**
 * Transaction-Autopilot — Restrained Fintech Smooth Scrolling Engine (Lenis)
 * Repository: https://github.com/darkroomengineering/lenis
 * 
 * Provides subtle, high-precision velocity damping for long-form merchant ledgers,
 * financial metric cards, and forensic trees.
 * 
 * Design Standards:
 * 1. Restrained physics: Snappy duration (0.85s) and gentle lerp (0.1) — zero floatiness or latency.
 * 2. Reduced motion respect: Automatically falls back to native instant scrolling if user prefers reduced motion.
 * 3. Native touch preservation: Touch scrolling on mobile/tablet is 100% native (syncTouch: false).
 * 4. Scroll isolation: data-lenis-prevent guards sidebar navigation, modal dialogs, and nested tables.
 * 5. Single RAF loop: Leverages built-in autoRaf to avoid conflicting animation loops.
 * 6. Clean lifecycle: Singleton instance with idempotent init and clean destroy teardown.
 */

(function () {
  'use strict';

  class SmoothScrollManager {
    constructor() {
      this.lenis = null;
      this.initialized = false;
      this.reducedMotionMediaQuery = typeof window !== 'undefined' && window.matchMedia
        ? window.matchMedia('(prefers-reduced-motion: reduce)')
        : null;
    }

    /**
     * Initialize Lenis smooth scroll singleton
     */
    init() {
      if (this.initialized && this.lenis) {
        return this.lenis;
      }

      if (typeof window === 'undefined' || typeof document === 'undefined') {
        return null;
      }

      // Check availability of Lenis global constructor (from lenis.min.js)
      if (typeof window.Lenis !== 'function') {
        console.info('[SmoothScroll] Lenis global constructor not available; native scrolling retained.');
        return null;
      }

      // Check reduced motion preference
      const prefersReducedMotion = Boolean(
        this.reducedMotionMediaQuery && this.reducedMotionMediaQuery.matches
      );

      try {
        this.lenis = new window.Lenis({
          duration: 0.85,                           // Restrained duration suited for fintech data
          lerp: 0.1,                                // Snappy linear interpolation (no floatiness)
          easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)), // Clean exponential deceleration
          orientation: 'vertical',
          gestureOrientation: 'vertical',
          smoothWheel: !prefersReducedMotion,       // Smooth wheel on desktop; immediate if reduced-motion
          syncTouch: false,                         // Touch is 100% native on iOS and Android
          touchMultiplier: 1,
          wheelMultiplier: 1,
          autoResize: true,                         // Adapt to dynamic DOM / panel expansions
          autoRaf: true,                            // Internal single requestAnimationFrame loop
          allowNestedScroll: true,                  // Preserve native nested scroll containers
          respectReducedMotion: true,               // Built-in reduced motion fallback
          anchors: false                            // Handled via application router
        });

        this.initialized = true;
        window.lenisInstance = this.lenis;

        // Apply scroll-isolation guards to nested scrollable areas
        this.applyScrollGuards();
        this.setupMutationObserver();

        // Listen for OS reduced-motion changes live
        if (this.reducedMotionMediaQuery && this.reducedMotionMediaQuery.addEventListener && !this.reducedMotionListenerAttached) {
          this.reducedMotionListenerAttached = true;
          this.reducedMotionMediaQuery.addEventListener('change', (e) => {
            if (e.matches) {
              // Destroy Lenis instance on reduced motion to restore 100% native browser scrolling
              this.destroy();
            } else {
              // Re-initialize Lenis when normal motion preference is restored
              this.init();
            }
          });
        }

        // Cleanup on page unload
        window.addEventListener('beforeunload', () => {
          this.destroy();
        }, { once: true });

        return this.lenis;
      } catch (err) {
        console.warn('[SmoothScroll] Lenis initialization error:', err);
        return null;
      }
    }

    /**
     * Observe DOM additions to automatically guard dynamically minted modals and drawers
     */
    setupMutationObserver() {
      if (typeof MutationObserver !== 'undefined' && document.body && !this.mutationObserver) {
        this.mutationObserver = new MutationObserver(() => {
          this.applyScrollGuards();
        });
        this.mutationObserver.observe(document.body, { childList: true, subtree: true });
      }
    }

    /**
     * Add data-lenis-prevent to nested scrollable containers so Lenis does not hijack them
     */
    applyScrollGuards() {
      const selectors = [
        '.sidebar',
        '.sidebar-nav',
        '.modal-dialog',
        '.modal-body',
        '.pp-modal',
        '.pp-modal-body',
        '.pp-modal-backdrop',
        '.modal-overlay',
        '.recent-table-wrapper',
        '#activity-table-wrapper',
        '.topbar-merchant-menu',
        '#notifications-modal-container',
        '#invoice-modal-container',
        '#help-modal-container',
        '#product-modal-container',
        '#capture-modal-container'
      ];

      selectors.forEach((sel) => {
        document.querySelectorAll(sel).forEach((el) => {
          if (!el.hasAttribute('data-lenis-prevent')) {
            el.setAttribute('data-lenis-prevent', '');
          }
        });
      });
    }

    /**
     * Programmatic scroll to target with fallback
     */
    scrollTo(target, options = {}) {
      if (this.lenis && this.initialized && !this.isReducedMotion()) {
        this.lenis.scrollTo(target, {
          duration: 0.5,
          immediate: false,
          lock: false,
          ...options
        });
      } else {
        const top = typeof target === 'number' ? target : 0;
        window.scrollTo({ top, behavior: this.isReducedMotion() ? 'auto' : 'smooth' });
      }
    }

    /**
     * Check if user prefers reduced motion
     */
    isReducedMotion() {
      return Boolean(this.reducedMotionMediaQuery && this.reducedMotionMediaQuery.matches);
    }

    /**
     * Clean up Lenis instance
     */
    destroy() {
      if (this.mutationObserver) {
        this.mutationObserver.disconnect();
        this.mutationObserver = null;
      }
      if (this.lenis) {
        try {
          this.lenis.destroy();
        } catch (_) {}
        this.lenis = null;
        this.initialized = false;
        window.lenisInstance = null;
      }
    }
  }

  // Global Singleton Instance
  const smoothScrollManager = new SmoothScrollManager();

  // Self-initialize once DOM content is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => smoothScrollManager.init());
  } else {
    smoothScrollManager.init();
  }

  // Expose to window for application consumption
  window.smoothScrollManager = smoothScrollManager;
  window.initSmoothScroll = () => smoothScrollManager.init();
  window.destroySmoothScroll = () => smoothScrollManager.destroy();
  window.scrollToSmooth = (target, options) => smoothScrollManager.scrollTo(target, options);

})();
