/**
 * Transaction-Autopilot — Illustrative Demo Dataset
 * Explicitly badged as simulated demonstration data for hackathon evaluation.
 * Faithfully implements the flagship PayPal Completed + Merchant Order Created + Missing Fulfillment scenario.
 */

export const INITIAL_TRANSACTIONS = [
  {
    id: 'TRX-9042',
    paypalCaptureId: 'CAP-982134',
    merchantOrderId: 'ORD-84920',
    customerName: 'Elena Rostova',
    customerEmail: 'elena.rostova@nexus.com',
    amount: 349.00,
    currency: 'USD',
    timestamp: '2026-10-10T09:14:22Z',
    paypalStatus: 'COMPLETED',
    merchantStatus: 'CREATED',
    fulfillmentStatus: 'NOT_DETECTED',
    overallHealth: 'CRITICAL',
    discrepancyType: 'MISSING_FULFILLMENT_EVENT',
    discrepancyTitle: 'Payment Captured, Fulfillment Confirmation Missing (36h+)',
    discrepancySummary: 'PayPal settlement completed 36 hours ago and merchant store created order #ORD-84920, but no warehouse dispatch or tracking event has been recorded across merchant event logs.',
    dataSource: 'PayPal Webhook + Shopify REST Sync',
    environment: 'Simulated Sandbox Data',
    events: [
      {
        id: 'EVT-9042-1',
        title: 'PayPal Checkout Session Approved',
        system: 'PayPal REST v2',
        timestamp: '2026-10-10T09:12:05Z',
        status: 'VERIFIED',
        details: 'Buyer authenticated and approved payment authorization token #EC-488921.',
        payload: { intent: 'CAPTURE', payer_id: 'PAYER-99218', amount: '349.00', currency: 'USD' }
      },
      {
        id: 'EVT-9042-2',
        title: 'PayPal Payment Capture Completed',
        system: 'PayPal REST v2',
        timestamp: '2026-10-10T09:14:22Z',
        status: 'VERIFIED',
        details: 'Funds captured into merchant account balance. Transaction fee: $10.42 USD. Net: $338.58 USD.',
        payload: { capture_id: 'CAP-982134', status: 'COMPLETED', final_capture: true, seller_protection: 'ELIGIBLE' }
      },
      {
        id: 'EVT-9042-3',
        title: 'Merchant Order Created in Shopify',
        system: 'Merchant eCommerce',
        timestamp: '2026-10-10T09:15:10Z',
        status: 'VERIFIED',
        details: 'Store created order #ORD-84920 with 2 items (SKU: WH-9921, SKU: WH-4412). State: PENDING_FULFILLMENT.',
        payload: { order_number: 'ORD-84920', financial_status: 'PAID', fulfillment_status: null }
      },
      {
        id: 'EVT-9042-4',
        title: '3PL Warehouse Fulfillment Confirmation',
        system: '3PL Logistics Webhook',
        timestamp: null,
        status: 'MISSING',
        details: 'Expected within 12 hours of capture. No fulfillment, dispatch, or tracking event received after 36h.',
        payload: { error: 'EVENT_NOT_RECEIVED', elapsed_hours: 36.4, tracking_number: null }
      }
    ],
    aiDiagnosis: {
      headline: 'Payment Captured without Downstream Warehouse Dispatch',
      confidence: 94,
      confidenceRationale: 'Deterministic confirmation of PayPal capture and Shopify order creation, coupled with complete absence of warehouse API calls for >36h.',
      verifiedFacts: [
        'PayPal payment captured successfully at 2026-10-10 09:14:22 UTC (#CAP-982134).',
        'Shopify order record #ORD-84920 successfully registered at 2026-10-10 09:15:10 UTC.',
        'Zero tracking number generation or 3PL API dispatch calls observed in merchant event stream.'
      ],
      hypotheses: [
        '3PL webhook endpoint suffered a connection timeout during 09:15 UTC maintenance window.',
        'Inventory allocation lock on SKU #WH-9921 halted automated batch export to distribution center.'
      ],
      missingInformation: [
        '3PL distribution center warehouse management system (WMS) acknowledgement receipt.',
        'Stock availability confirmation for warehouse zone East-2.'
      ],
      recommendedRecovery: [
        {
          step: 1,
          title: 'Ping 3PL Fulfillment API for Order Status',
          risk: 'SAFE',
          requiresApproval: false,
          actionType: 'READ_PROBE'
        },
        {
          step: 2,
          title: 'Reconcile Merchant Inventory Ledger against SKU #WH-9921',
          risk: 'SAFE',
          requiresApproval: false,
          actionType: 'READ_PROBE'
        },
        {
          step: 3,
          title: 'Trigger Order Re-queue & Re-dispatch Webhook to Warehouse',
          risk: 'SENSITIVE',
          requiresApproval: true,
          actionType: 'EXECUTE_MUTATION'
        },
        {
          step: 4,
          title: 'Send Pre-emptive Customer Shipping Assurance Notice',
          risk: 'SAFE',
          requiresApproval: false,
          actionType: 'SEND_NOTICE'
        }
      ]
    }
  },
  {
    id: 'TRX-9043',
    paypalCaptureId: 'CAP-982135',
    merchantOrderId: 'ORD-84921',
    customerName: 'Marcus Vance',
    customerEmail: 'marcus.vance@techcorp.io',
    amount: 1250.00,
    currency: 'USD',
    timestamp: '2026-10-10T11:45:00Z',
    paypalStatus: 'COMPLETED',
    merchantStatus: 'FULFILLED',
    fulfillmentStatus: 'DELIVERED',
    overallHealth: 'HEALTHY',
    discrepancyType: 'NONE',
    discrepancyTitle: 'Fully Reconciled & Delivered',
    discrepancySummary: 'PayPal settlement, store order, and FedEx tracking #7792182910 completely in sync.',
    dataSource: 'PayPal REST + ShipStation',
    environment: 'Simulated Sandbox Data',
    events: [
      { id: 'EVT-9043-1', title: 'PayPal Capture Completed', system: 'PayPal REST v2', timestamp: '2026-10-10T11:45:00Z', status: 'VERIFIED', details: 'Settled $1,250.00 USD.' },
      { id: 'EVT-9043-2', title: 'Order Fulfilled & Tracking Generated', system: 'ShipStation', timestamp: '2026-10-10T14:10:15Z', status: 'VERIFIED', details: 'FedEx #7792182910' }
    ]
  },
  {
    id: 'TRX-9038',
    paypalCaptureId: 'CAP-982130',
    merchantOrderId: 'ORD-84916',
    customerName: 'Amina Al-Mansoor',
    customerEmail: 'amina.m@globalreach.ae',
    amount: 890.50,
    currency: 'USD',
    timestamp: '2026-10-09T18:20:10Z',
    paypalStatus: 'COMPLETED',
    merchantStatus: 'CANCELED',
    fulfillmentStatus: 'UNFULFILLED',
    overallHealth: 'CRITICAL',
    discrepancyType: 'STATE_MISMATCH_UNREFUNDED',
    discrepancyTitle: 'Order Canceled in Store but Payment Captured without Refund',
    discrepancySummary: 'Merchant canceled order due to buyer request, but PayPal capture #CAP-982130 remains unrefunded. Risk of buyer dispute.',
    dataSource: 'Shopify Webhook + PayPal Audit',
    environment: 'Simulated Sandbox Data',
    events: [
      { id: 'EVT-9038-1', title: 'PayPal Capture Completed', system: 'PayPal REST v2', timestamp: '2026-10-09T18:20:10Z', status: 'VERIFIED', details: 'Captured $890.50 USD.' },
      { id: 'EVT-9038-2', title: 'Merchant Order Canceled by Admin', system: 'Shopify', timestamp: '2026-10-09T19:05:00Z', status: 'VERIFIED', details: 'Reason: Customer cancellation.' },
      { id: 'EVT-9038-3', title: 'PayPal Refund Execution', system: 'PayPal REST v2', timestamp: null, status: 'MISSING', details: 'Refund webhook was never triggered.' }
    ],
    aiDiagnosis: {
      headline: 'Financial Settlement Retained for Canceled Order',
      confidence: 98,
      confidenceRationale: 'Shopify cancellation event confirmed, PayPal capture remains unsettled in refund status.',
      verifiedFacts: [
        'Payment captured at 2026-10-09 18:20:10 UTC.',
        'Order canceled in merchant platform at 2026-10-09 19:05:00 UTC.',
        'No refund record exists in PayPal transaction history.'
      ],
      hypotheses: [
        'Merchant staff canceled order manually without selecting "Issue refund via payment gateway".'
      ],
      missingInformation: ['Proof of external merchant credit or store gift card issued.'],
      recommendedRecovery: [
        { step: 1, title: 'Verify if manual store credit was offered', risk: 'SAFE', requiresApproval: false },
        { step: 2, title: 'Queue PayPal Refund of $890.50 for Human Approval', risk: 'SENSITIVE', requiresApproval: true }
      ]
    }
  },
  {
    id: 'TRX-9031',
    paypalCaptureId: 'AUTH-881290',
    merchantOrderId: 'ORD-84909',
    customerName: 'Liam O’Connor',
    customerEmail: 'liam.oc@celtictech.ie',
    amount: 185.00,
    currency: 'USD',
    timestamp: '2026-10-09T14:10:00Z',
    paypalStatus: 'PENDING',
    merchantStatus: 'PROCESSING',
    fulfillmentStatus: 'PENDING',
    overallHealth: 'WARNING',
    discrepancyType: 'STUCK_IN_AUTHORIZATION',
    discrepancyTitle: 'Authorization Stalled (Capture Window Expiring in 18h)',
    discrepancySummary: 'PayPal authorized payment 54 hours ago, but capture API was never invoked. Merchant holds inventory without secured funds.',
    dataSource: 'PayPal Orders API',
    environment: 'Simulated Sandbox Data',
    events: [
      { id: 'EVT-9031-1', title: 'PayPal Authorization Created', system: 'PayPal Orders v2', timestamp: '2026-10-09T14:10:00Z', status: 'VERIFIED', details: 'Authorized $185.00 USD. Valid for 72h.' }
    ]
  },
  {
    id: 'TRX-9029',
    paypalCaptureId: 'CAP-982120',
    merchantOrderId: 'ORD-84907',
    customerName: 'Sofia Chen',
    customerEmail: 'sofia.chen@apex.org',
    amount: 420.00,
    currency: 'USD',
    timestamp: '2026-10-09T10:00:00Z',
    paypalStatus: 'COMPLETED',
    merchantStatus: 'FULFILLED',
    fulfillmentStatus: 'IN_TRANSIT',
    overallHealth: 'HEALTHY',
    discrepancyType: 'NONE',
    discrepancyTitle: 'Fully Reconciled & In Transit',
    discrepancySummary: 'All 3 state layers healthy and synchronized.',
    dataSource: 'PayPal REST + UPS Webhook',
    environment: 'Simulated Sandbox Data'
  },
  {
    id: 'TRX-9025',
    paypalCaptureId: 'CAP-982115',
    merchantOrderId: 'ORD-84902',
    customerName: 'David K. Miller',
    customerEmail: 'david.m@millereng.com',
    amount: 2150.00,
    currency: 'USD',
    timestamp: '2026-10-08T22:15:30Z',
    paypalStatus: 'COMPLETED',
    merchantStatus: 'FULFILLED',
    fulfillmentStatus: 'DELIVERED',
    overallHealth: 'HEALTHY',
    discrepancyType: 'NONE',
    discrepancyTitle: 'Completed & Verified',
    discrepancySummary: 'All milestones satisfied with customer delivery confirmation.',
    dataSource: 'PayPal REST + DHL Express',
    environment: 'Simulated Sandbox Data'
  },
  {
    id: 'TRX-9022',
    paypalCaptureId: 'CAP-982112',
    merchantOrderId: 'ORD-84899',
    customerName: 'Nadia Petrova',
    customerEmail: 'nadia.p@petrovadesign.com',
    amount: 670.00,
    currency: 'USD',
    timestamp: '2026-10-08T16:30:00Z',
    paypalStatus: 'COMPLETED',
    merchantStatus: 'CREATED',
    fulfillmentStatus: 'NOT_DETECTED',
    overallHealth: 'WARNING',
    discrepancyType: 'MISSING_FULFILLMENT_EVENT',
    discrepancyTitle: 'Fulfillment Pending over 48 Hours',
    discrepancySummary: 'Captured funds received, order awaiting fulfillment queue dispatch.',
    dataSource: 'PayPal REST + WooCommerce',
    environment: 'Simulated Sandbox Data'
  },
  {
    id: 'TRX-9018',
    paypalCaptureId: 'CAP-982108',
    merchantOrderId: 'ORD-84895',
    customerName: 'Kenji Sato',
    customerEmail: 'k.sato@tokyomedia.jp',
    amount: 540.00,
    currency: 'USD',
    timestamp: '2026-10-08T12:00:00Z',
    paypalStatus: 'COMPLETED',
    merchantStatus: 'FULFILLED',
    fulfillmentStatus: 'DELIVERED',
    overallHealth: 'HEALTHY',
    discrepancyType: 'NONE',
    discrepancyTitle: 'Reconciled',
    discrepancySummary: 'Standard checkout and fulfillment completed smoothly.',
    dataSource: 'PayPal REST + JapanPost',
    environment: 'Simulated Sandbox Data'
  }
];

export const INITIAL_APPROVALS = [
  {
    id: 'APP-101',
    transactionId: 'TRX-9042',
    actionType: 'RE_DISPATCH_FULFILLMENT',
    actionTitle: 'Re-dispatch 3PL Fulfillment Webhook for Order #ORD-84920',
    description: 'Trigger automated order re-submission to 3PL warehouse queue with priority dispatch flag and verify inventory allocation.',
    amount: 349.00,
    currency: 'USD',
    riskLevel: 'HIGH',
    impact: 'Will initiate physical order dispatch and warehouse picking sequence.',
    requestedBy: 'AI Reliability Agent (Autopilot v2)',
    timestamp: '2026-10-10T14:30:00Z',
    status: 'PENDING',
    justification: 'Payment was captured 36h ago and confirmed in PayPal. Shopify record exists. Order is blocked solely due to dropped 3PL event.'
  },
  {
    id: 'APP-102',
    transactionId: 'TRX-9038',
    actionType: 'ISSUE_PAYPAL_REFUND',
    actionTitle: 'Issue PayPal Refund of $890.50 for Canceled Order #ORD-84916',
    description: 'Execute API refund via PayPal REST v2 endpoint to return settled funds to buyer card following order cancellation.',
    amount: 890.50,
    currency: 'USD',
    riskLevel: 'CRITICAL',
    impact: 'Direct debit of $890.50 from merchant PayPal balance to buyer.',
    requestedBy: 'AI Reliability Agent (Autopilot v2)',
    timestamp: '2026-10-10T10:15:00Z',
    status: 'PENDING',
    justification: 'Merchant marked order canceled in store 24 hours ago. Capture #CAP-982130 remains unrefunded.'
  },
  {
    id: 'APP-103',
    transactionId: 'TRX-9031',
    actionType: 'EXECUTE_PAYPAL_CAPTURE',
    actionTitle: 'Capture Stalled PayPal Authorization #AUTH-881290 ($185.00)',
    description: 'Invoke PayPal Capture endpoint before authorization expires at 72-hour mark.',
    amount: 185.00,
    currency: 'USD',
    riskLevel: 'MEDIUM',
    impact: 'Captures $185.00 from buyer bank and marks store order as paid.',
    requestedBy: 'AI Reliability Agent (Autopilot v2)',
    timestamp: '2026-10-10T15:00:00Z',
    status: 'PENDING',
    justification: 'Order is packed in warehouse and ready for dispatch. Authorization expires in 18 hours.'
  }
];

export const INITIAL_AUDIT_LOGS = [
  {
    id: 'AUD-501',
    timestamp: '2026-10-10T14:30:15Z',
    transactionId: 'TRX-9042',
    action: 'DISCREPANCY_FLAGGED',
    actor: 'AI Inconsistency Detector',
    source: 'Automated 15m Reconciliation Cron',
    outcome: 'FLAGGED_FOR_HUMAN_REVIEW',
    details: 'Detected 36h gap between PayPal capture #CAP-982134 and 3PL dispatch. Queued recommendation for human review.'
  },
  {
    id: 'AUD-502',
    timestamp: '2026-10-10T10:15:22Z',
    transactionId: 'TRX-9038',
    action: 'APPROVAL_REQUEST_CREATED',
    actor: 'Autopilot Rule Engine',
    source: 'Shopify Webhook Listener',
    outcome: 'QUEUED',
    details: 'Created approval item APP-102 for unrefunded canceled order of $890.50 USD.'
  },
  {
    id: 'AUD-503',
    timestamp: '2026-10-10T08:12:00Z',
    transactionId: 'TRX-9025',
    action: 'TRANSACTION_RECONCILED',
    actor: 'Ledger Engine',
    source: 'DHL Webhook Ingestion',
    outcome: 'AUTO_RESOLVED',
    details: 'Matched delivery confirmation #DHL-882190 to PayPal capture #CAP-982115. Overall health marked HEALTHY.'
  },
  {
    id: 'AUD-504',
    timestamp: '2026-10-09T14:10:05Z',
    transactionId: 'TRX-9031',
    action: 'AUTHORIZATION_RECORDED',
    actor: 'PayPal Webhook Gateway',
    source: 'PAYMENT.AUTHORIZATION.CREATED',
    outcome: 'STORED',
    details: 'Recorded PayPal Auth #AUTH-881290 ($185.00 USD). Capture window timer started (72h).'
  }
];
