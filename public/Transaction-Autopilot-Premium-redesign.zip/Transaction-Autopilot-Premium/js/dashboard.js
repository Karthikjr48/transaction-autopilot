/**
 * Transaction-Autopilot — Overview Dashboard
 * Real-time operational health, discrepancy spotlight, recent ledger, and recovery shortcuts
 */

import { store } from './state.js';
import { formatCurrency, formatTimeAgo, escapeHTML } from './utils.js';
import { getIcon } from './icons.js';
import { renderVolumeChart, renderHealthDonut } from './charts.js';

export function initDashboard() {
  renderDashboardKPIs();
  renderCriticalBanner();
  renderDashboardCharts();
  renderRecentTransactions();
  renderRecentInvestigationsStream();
  renderDashboardRecoveryPreview();

  // Listen to store changes
  store.subscribe('transactionsChanged', () => {
    renderDashboardKPIs();
    renderCriticalBanner();
    renderDashboardCharts();
    renderRecentTransactions();
    renderDashboardRecoveryPreview();
  });
}

/**
 * Render 4 Top KPI Cards
 */
function renderDashboardKPIs() {
  const container = document.getElementById('dashboard-kpis');
  if (!container) return;

  const metrics = store.getDashboardMetrics();

  container.innerHTML = `
    <div class="kpi-card">
      <div class="kpi-header">
        <span class="kpi-label">24h Transaction Volume</span>
        <div class="kpi-icon-wrapper blue">${getIcon('dollar')}</div>
      </div>
      <div class="kpi-value tabular-nums">${formatCurrency(metrics.totalVolume)}</div>
      <div class="kpi-meta">
        <span class="kpi-trend positive">&uarr; +14.2%</span>
        <span>vs yesterday</span>
      </div>
    </div>

    <div class="kpi-card">
      <div class="kpi-header">
        <span class="kpi-label">Healthy Pipeline Rate</span>
        <div class="kpi-icon-wrapper green">${getIcon('checkCircle')}</div>
      </div>
      <div class="kpi-value tabular-nums">${metrics.healthyRate}%</div>
      <div class="kpi-meta">
        <span class="kpi-trend positive">&uarr; +0.8%</span>
        <span>${metrics.healthyCount} of ${metrics.totalCount} synchronized</span>
      </div>
    </div>

    <div class="kpi-card critical-accent">
      <div class="kpi-header">
        <span class="kpi-label">Issues Detected</span>
        <div class="kpi-icon-wrapper red">${getIcon('alertTriangle')}</div>
      </div>
      <div class="kpi-value tabular-nums" style="color:var(--color-critical);">${metrics.issuesCount}</div>
      <div class="kpi-meta">
        <span class="kpi-trend negative">${metrics.criticalCount} Critical</span>
        <span>${metrics.warningCount} Stalled</span>
      </div>
    </div>

    <div class="kpi-card">
      <div class="kpi-header">
        <span class="kpi-label">Pending Human Approvals</span>
        <div class="kpi-icon-wrapper amber">${getIcon('shield')}</div>
      </div>
      <div class="kpi-value tabular-nums" style="color:var(--color-warning);">${metrics.pendingApprovalsCount}</div>
      <div class="kpi-meta">
        <span>Sensitive actions awaiting sign-off</span>
      </div>
    </div>
  `;
}

/**
 * Render Critical Discrepancy Spotlight
 */
function renderCriticalBanner() {
  const container = document.getElementById('discrepancy-spotlight');
  if (!container) return;

  const criticalTrx = store.transactions.find(t => t.id === 'TRX-9042');
  if (!criticalTrx) {
    container.innerHTML = '';
    return;
  }

  container.innerHTML = `
    <div class="discrepancy-banner">
      <div class="discrepancy-content">
        <div class="discrepancy-icon-box">
          ${getIcon('alertTriangle')}
        </div>
        <div>
          <div class="discrepancy-title">Critical Inconsistency: ${escapeHTML(criticalTrx.discrepancyTitle)}</div>
          <div class="discrepancy-desc">
            Transaction <span class="discrepancy-highlight mono">${criticalTrx.id}</span> (${formatCurrency(criticalTrx.amount)})
            &bull; PayPal capture <span class="mono">${criticalTrx.paypalCaptureId}</span> settled, but warehouse fulfillment confirmation is missing for over 36 hours.
          </div>
        </div>
      </div>
      <div class="discrepancy-actions">
        <button class="btn btn-primary" id="btn-investigate-spotlight">
          ${getIcon('investigations')}
          Launch AI Investigation
        </button>
      </div>
    </div>
  `;

  const btn = document.getElementById('btn-investigate-spotlight');
  if (btn) {
    btn.addEventListener('click', () => {
      store.setSelectedTransaction('TRX-9042');
      store.setView('investigations');
    });
  }
}

/**
 * Render Canvas & Donut charts
 */
function renderDashboardCharts() {
  setTimeout(() => {
    renderVolumeChart('volume-chart-canvas');
    renderHealthDonut('health-donut-container', store.getDashboardMetrics());
  }, 50);
}

/**
 * Render Recent Transactions Table
 */
function renderRecentTransactions() {
  const tbody = document.getElementById('recent-transactions-tbody');
  if (!tbody) return;

  const recent = store.transactions.slice(0, 5);

  tbody.innerHTML = recent.map(t => {
    const isCritical = t.overallHealth === 'CRITICAL';
    const isWarning = t.overallHealth === 'WARNING';
    const rowClass = isCritical ? 'row-flagged' : '';

    return `
      <tr class="${rowClass}" data-trx-id="${t.id}">
        <td>
          <span class="mono" style="font-weight:600;color:var(--color-navy-900);">${t.id}</span>
          <div style="font-size:11px;color:var(--color-text-tertiary);">${escapeHTML(t.customerName)}</div>
        </td>
        <td class="tabular-nums" style="font-weight:600;">
          ${formatCurrency(t.amount, t.currency)}
        </td>
        <td>
          ${renderBadge(t.paypalStatus, t.paypalStatus === 'COMPLETED' ? 'success' : 'warning')}
        </td>
        <td>
          ${renderBadge(t.merchantStatus, t.merchantStatus === 'FULFILLED' ? 'success' : (t.merchantStatus === 'CANCELED' ? 'critical' : 'neutral'))}
        </td>
        <td>
          ${renderFulfillmentBadge(t.fulfillmentStatus)}
        </td>
        <td style="color:var(--color-text-tertiary);font-size:12px;">
          ${formatTimeAgo(t.timestamp)}
        </td>
        <td style="text-align:right;">
          <button class="btn btn-sm btn-secondary btn-table-investigate" data-id="${t.id}">
            ${getIcon('investigations')}
            Investigate
          </button>
        </td>
      </tr>
    `;
  }).join('');

  // Attach click handlers
  tbody.querySelectorAll('.btn-table-investigate').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const trxId = btn.getAttribute('data-id');
      store.setSelectedTransaction(trxId);
      store.setView('investigations');
    });
  });

  tbody.querySelectorAll('tr').forEach(row => {
    row.addEventListener('click', () => {
      const trxId = row.getAttribute('data-trx-id');
      if (trxId) {
        store.setSelectedTransaction(trxId);
        store.setView('investigations');
      }
    });
  });
}

function renderBadge(text, variant) {
  return `<span class="badge badge-${variant}"><span class="badge-dot"></span>${text}</span>`;
}

function renderFulfillmentBadge(status) {
  if (status === 'DELIVERED' || status === 'IN_TRANSIT') {
    return `<span class="badge badge-success"><span class="badge-dot"></span>${status}</span>`;
  }
  if (status === 'NOT_DETECTED') {
    return `<span class="badge badge-critical pulse-badge"><span class="badge-dot"></span>NOT DETECTED</span>`;
  }
  return `<span class="badge badge-warning"><span class="badge-dot"></span>${status}</span>`;
}

/**
 * Render Recent Investigation Activity Stream
 */
function renderRecentInvestigationsStream() {
  const container = document.getElementById('recent-activity-stream');
  if (!container) return;

  const activities = [
    { title: 'Inconsistency Flagged on TRX-9042', time: '14m ago', desc: 'PayPal Capture completed, 0 fulfillment dispatch events recorded.', type: 'critical' },
    { title: 'Refund Queued for Human Review', time: '2h ago', desc: 'TRX-9038 store order was canceled while payment was retained.', type: 'warning' },
    { title: 'Auto-Reconciliation Succeeded', time: '4h ago', desc: 'Matched FedEx delivery confirmation for TRX-9043.', type: 'success' }
  ];

  container.innerHTML = activities.map(a => `
    <div style="display:flex;align-items:flex-start;gap:12px;padding:10px 0;border-bottom:1px solid var(--color-border-subtle);">
      <div style="margin-top:2px;color:${a.type === 'critical' ? 'var(--color-critical)' : (a.type === 'warning' ? 'var(--color-warning)' : 'var(--color-success)')};">
        ${getIcon(a.type === 'critical' ? 'alertTriangle' : (a.type === 'warning' ? 'shield' : 'checkCircle'))}
      </div>
      <div style="flex:1;">
        <div style="display:flex;align-items:center;justify-content:space-between;">
          <strong style="font-size:13px;color:var(--color-navy-900);">${escapeHTML(a.title)}</strong>
          <span style="font-size:11px;color:var(--color-text-muted);font-family:var(--font-mono);">${a.time}</span>
        </div>
        <p style="font-size:12px;color:var(--color-text-secondary);margin-top:2px;">${escapeHTML(a.desc)}</p>
      </div>
    </div>
  `).join('');
}

/**
 * Render Dashboard Recovery Playbook Preview
 */
function renderDashboardRecoveryPreview() {
  const container = document.getElementById('dashboard-recovery-preview');
  if (!container) return;

  const pendingApprovals = store.approvals.filter(a => a.status === 'PENDING');

  container.innerHTML = `
    <div style="display:flex;flex-direction:column;gap:12px;">
      <div style="display:flex;align-items:center;justify-content:space-between;font-size:13px;">
        <span style="color:var(--color-text-secondary);">High-Priority Recovery Queue</span>
        <span class="badge badge-warning">${pendingApprovals.length} Awaiting Approval</span>
      </div>
      ${pendingApprovals.map(item => `
        <div style="padding:10px 12px;border:1px solid var(--color-border-default);border-radius:var(--radius-md);background:var(--color-bg-page);display:flex;align-items:center;justify-content:space-between;gap:8px;">
          <div>
            <div style="font-size:12px;font-weight:600;color:var(--color-navy-900);">${escapeHTML(item.actionTitle)}</div>
            <div style="font-size:11px;color:var(--color-text-tertiary);">${item.transactionId} &bull; ${formatCurrency(item.amount)}</div>
          </div>
          <button class="btn btn-sm btn-primary btn-quick-approve" data-id="${item.id}">
            Review
          </button>
        </div>
      `).join('')}
    </div>
  `;

  container.querySelectorAll('.btn-quick-approve').forEach(b => {
    b.addEventListener('click', () => {
      store.setView('approvals');
    });
  });
}
