/**
 * Transaction-Autopilot — Reactive State Management
 * Centralized store coordinating transactions, human approvals, audit trail, and active view state
 */

import { INITIAL_TRANSACTIONS, INITIAL_APPROVALS, INITIAL_AUDIT_LOGS } from './data.js';

class StateStore {
  constructor() {
    this.transactions = [...INITIAL_TRANSACTIONS];
    this.approvals = [...INITIAL_APPROVALS];
    this.auditLogs = [...INITIAL_AUDIT_LOGS];
    this.selectedTransactionId = 'TRX-9042'; // Default to the flagship demonstration case
    this.activeView = 'overview';
    this.listeners = new Map();
  }

  subscribe(eventName, callback) {
    if (!this.listeners.has(eventName)) {
      this.listeners.set(eventName, new Set());
    }
    this.listeners.get(eventName).add(callback);
    return () => this.listeners.get(eventName).delete(callback);
  }

  notify(eventName, payload) {
    if (this.listeners.has(eventName)) {
      this.listeners.get(eventName).forEach(cb => cb(payload));
    }
  }

  /**
   * Set active navigation view
   */
  setView(viewName) {
    this.activeView = viewName;
    this.notify('viewChanged', viewName);
  }

  /**
   * Select a transaction for the AI Investigation view
   */
  setSelectedTransaction(trxId) {
    this.selectedTransactionId = trxId;
    this.notify('transactionSelected', this.getSelectedTransaction());
  }

  getSelectedTransaction() {
    return this.transactions.find(t => t.id === this.selectedTransactionId) || this.transactions[0];
  }

  getTransactionById(id) {
    return this.transactions.find(t => t.id === id);
  }

  /**
   * Human-in-the-loop: Approve sensitive action
   */
  approveAction(approvalId, operatorNote = '') {
    const item = this.approvals.find(a => a.id === approvalId);
    if (!item) return { success: false, error: 'Approval item not found' };

    item.status = 'APPROVED';
    item.decidedAt = new Date().toISOString();
    item.decidedBy = 'Merchant Operations Lead (Elena S.)';
    item.operatorNote = operatorNote;

    // Mutate the corresponding transaction demo state
    const trx = this.getTransactionById(item.transactionId);
    if (trx) {
      if (item.actionType === 'RE_DISPATCH_FULFILLMENT') {
        trx.fulfillmentStatus = 'DISPATCH_QUEUED';
        trx.overallHealth = 'WARNING';
        trx.events.push({
          id: `EVT-${Date.now()}`,
          title: 'Warehouse Re-dispatch Webhook Executed (Human Approved)',
          system: 'Autopilot Dispatcher',
          timestamp: new Date().toISOString(),
          status: 'VERIFIED',
          details: `Re-dispatch triggered with priority flag. Note: "${operatorNote || 'Approved for immediate fulfillment'}".`,
          payload: { approval_id: approvalId, operator: item.decidedBy, simulated: true }
        });
      } else if (item.actionType === 'ISSUE_PAYPAL_REFUND') {
        trx.paypalStatus = 'REFUNDED';
        trx.overallHealth = 'HEALTHY';
        trx.events.push({
          id: `EVT-${Date.now()}`,
          title: 'PayPal Refund API Invoked (Human Approved)',
          system: 'PayPal REST v2',
          timestamp: new Date().toISOString(),
          status: 'VERIFIED',
          details: `Refund of $${trx.amount} USD processed to buyer card. Note: "${operatorNote}".`,
          payload: { refund_id: `REF-${Math.floor(100000 + Math.random() * 900000)}`, status: 'COMPLETED' }
        });
      } else if (item.actionType === 'EXECUTE_PAYPAL_CAPTURE') {
        trx.paypalStatus = 'COMPLETED';
        trx.overallHealth = 'HEALTHY';
        trx.events.push({
          id: `EVT-${Date.now()}`,
          title: 'PayPal Capture Completed (Human Approved)',
          system: 'PayPal REST v2',
          timestamp: new Date().toISOString(),
          status: 'VERIFIED',
          details: `Authorized funds captured successfully.`,
          payload: { capture_id: `CAP-${Math.floor(100000 + Math.random() * 900000)}`, status: 'COMPLETED' }
        });
      }
    }

    // Prepend to Audit Log
    const logEntry = {
      id: `AUD-${Date.now()}`,
      timestamp: new Date().toISOString(),
      transactionId: item.transactionId,
      action: 'ACTION_APPROVED',
      actor: item.decidedBy,
      source: 'Human Approval Queue',
      outcome: 'APPROVED_AND_EXECUTED',
      details: `Operator approved "${item.actionTitle}". Note: ${operatorNote || 'None'}. (Simulated local execution)`
    };
    this.auditLogs.unshift(logEntry);

    this.notify('approvalsChanged', this.approvals);
    this.notify('transactionsChanged', this.transactions);
    this.notify('auditLogsChanged', this.auditLogs);

    return { success: true, item, logEntry };
  }

  /**
   * Human-in-the-loop: Reject sensitive action
   */
  rejectAction(approvalId, operatorNote = '') {
    const item = this.approvals.find(a => a.id === approvalId);
    if (!item) return { success: false, error: 'Approval item not found' };

    item.status = 'REJECTED';
    item.decidedAt = new Date().toISOString();
    item.decidedBy = 'Merchant Operations Lead (Elena S.)';
    item.operatorNote = operatorNote;

    const logEntry = {
      id: `AUD-${Date.now()}`,
      timestamp: new Date().toISOString(),
      transactionId: item.transactionId,
      action: 'ACTION_REJECTED',
      actor: item.decidedBy,
      source: 'Human Approval Queue',
      outcome: 'BLOCKED_BY_OPERATOR',
      details: `Operator rejected "${item.actionTitle}". Reason: ${operatorNote || 'Rejected by operator'}.`
    };
    this.auditLogs.unshift(logEntry);

    this.notify('approvalsChanged', this.approvals);
    this.notify('auditLogsChanged', this.auditLogs);

    return { success: true, item, logEntry };
  }

  /**
   * Metrics calculation for Overview Dashboard
   */
  getDashboardMetrics() {
    const totalVolume = this.transactions.reduce((acc, t) => acc + (t.amount || 0), 0);
    const healthyCount = this.transactions.filter(t => t.overallHealth === 'HEALTHY').length;
    const criticalCount = this.transactions.filter(t => t.overallHealth === 'CRITICAL').length;
    const warningCount = this.transactions.filter(t => t.overallHealth === 'WARNING').length;
    const issuesCount = criticalCount + warningCount;
    const pendingApprovalsCount = this.approvals.filter(a => a.status === 'PENDING').length;
    const healthyRate = this.transactions.length ? ((healthyCount / this.transactions.length) * 100).toFixed(1) : 0;

    return {
      totalVolume,
      healthyCount,
      healthyRate,
      issuesCount,
      criticalCount,
      warningCount,
      pendingApprovalsCount,
      totalCount: this.transactions.length
    };
  }
}

export const store = new StateStore();
