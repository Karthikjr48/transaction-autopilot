/**
 * Transaction-Autopilot — Navigation & View Routing
 * Single-page router, sidebar active state, responsive mobile drawer, and URL hash sync
 */

import { store } from './state.js';

export function initNavigation() {
  setupSidebarNavigation();
  setupMobileDrawer();
  setupNotificationsPopover();
  setupGlobalShortcuts();

  // Handle URL hash changes
  window.addEventListener('hashchange', handleHashRouting);

  // Initial route
  handleHashRouting();

  // Listen to store view changes
  store.subscribe('viewChanged', (viewName) => {
    switchViewDOM(viewName);
    window.location.hash = viewName;
  });

  // Update notification count badge in topbar
  updateNotificationCount();
  store.subscribe('approvalsChanged', updateNotificationCount);
}

function setupSidebarNavigation() {
  const navLinks = document.querySelectorAll('.nav-link[data-view]');
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetView = link.getAttribute('data-view');
      store.setView(targetView);
      closeMobileDrawer();
    });
  });
}

function handleHashRouting() {
  const hash = window.location.hash.replace('#', '').trim();
  const validViews = ['overview', 'transactions', 'investigations', 'recovery', 'approvals', 'audit', 'settings'];
  const view = validViews.includes(hash) ? hash : 'overview';
  store.setView(view);
}

function switchViewDOM(viewName) {
  // Update nav links
  document.querySelectorAll('.nav-link[data-view]').forEach(link => {
    if (link.getAttribute('data-view') === viewName) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });

  // Switch view panels
  document.querySelectorAll('.view-panel').forEach(panel => {
    if (panel.id === `view-${viewName}`) {
      panel.classList.add('active');
    } else {
      panel.classList.remove('active');
    }
  });

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function setupMobileDrawer() {
  const menuBtn = document.getElementById('btn-mobile-menu');
  const sidebar = document.querySelector('.sidebar');
  const backdrop = document.getElementById('drawer-backdrop');

  if (menuBtn && sidebar && backdrop) {
    menuBtn.addEventListener('click', () => {
      sidebar.classList.toggle('mobile-open');
      backdrop.classList.toggle('active');
    });

    backdrop.addEventListener('click', closeMobileDrawer);
  }
}

function closeMobileDrawer() {
  const sidebar = document.querySelector('.sidebar');
  const backdrop = document.getElementById('drawer-backdrop');
  if (sidebar) sidebar.classList.remove('mobile-open');
  if (backdrop) backdrop.classList.remove('active');
}

function setupNotificationsPopover() {
  const bellBtn = document.getElementById('btn-notifications-bell');
  const popover = document.getElementById('notification-popover');

  if (bellBtn && popover) {
    bellBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      popover.classList.toggle('active');
    });

    document.addEventListener('click', (e) => {
      if (!popover.contains(e.target) && e.target !== bellBtn) {
        popover.classList.remove('active');
      }
    });
  }
}

function updateNotificationCount() {
  const countBadge = document.getElementById('topbar-notification-badge');
  const pending = store.approvals.filter(a => a.status === 'PENDING').length;
  if (countBadge) {
    countBadge.textContent = pending;
    countBadge.style.display = pending > 0 ? 'flex' : 'none';
  }
}

function setupGlobalShortcuts() {
  window.addEventListener('keydown', (e) => {
    // Cmd+K or Ctrl+K focuses global search
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      const search = document.getElementById('global-search-input');
      if (search) search.focus();
    }
  });

  const globalSearch = document.getElementById('global-search-input');
  if (globalSearch) {
    globalSearch.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const val = globalSearch.value.trim();
        if (val) {
          store.setView('transactions');
          const trxSearch = document.getElementById('trx-search-input');
          if (trxSearch) {
            trxSearch.value = val;
            trxSearch.dispatchEvent(new Event('input'));
          }
        }
      }
    });
  }
}
