/**
 * Transaction-Autopilot — Approval Queue
 * Human-in-the-loop safeguards: review AI proposed mutations, confirmation dialogs, and local state update
 */

import { store } from './state.js';
import { formatCurrency, formatDateTime, escapeHTML, showToast, openModal, closeModal } from './utils.js';
import { getIcon } from './icons.js';

let pendingActionToDecide = null;
let decisionType = null; // 'APPROVE' or 'REJECT'

export function initApprovalsView() {
  setupApprovalModal();
  renderApprovalsList();

  store.subscribe('approvalsChanged', () => {
    renderApprovalsList();
  });
}

export function renderApprovalsList() {
  const container = document.getElementById('approvals-list-container');
  const countBadge = document.getElementById('pending-approvals-count-badge');
  if (!container) return;

  const pending = store.approvals.filter(a => a.status === 'PENDING');
  const resolved = store.approvals.filter(a => a.status !== 'PENDING');

  if (countBadge) {
    countBadge.textContent = `${pending.length} pending`;
  }

  if (pending.length === 0 && resolved.length === 0) {
    container.innerHTML = `
      <div style="padding:40px;text-align:center;color:var(--color-text-tertiary);">
        ${getIcon('checkCircle', 'style="width:36px;height:36px;color:var(--color-success);margin-bottom:8px;"')}
        <div style="font-weight:600;font-size:14px;color:var(--color-navy-900);">No Actions Requiring Approval</div>
        <p style="font-size:12px;margin-top:4px;">All automated proposals have been reviewed and executed.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = `
    <!-- Pending Section -->
    <div style="margin-bottom:var(--space-6);">
      <h3 style="font-size:14px;text-transform:uppercase;letter-spacing:0.05em;color:var(--color-text-secondary);margin-bottom:12px;display:flex;align-items:center;gap:6px;">
        ${getIcon('shield')}
        Awaiting Human Sign-Off (${pending.length})
      </h3>

      ${pending.length === 0 ? `
        <div class="card" style="padding:24px;text-align:center;color:var(--color-text-tertiary);font-size:13px;">
          Queue clean. Zero sensitive actions currently blocked on operator review.
        </div>
      ` : `
        <div style="display:flex;flex-direction:column;gap:var(--space-4);">
          ${pending.map(item => `
            <div class="card" style="border-left:4px solid ${item.riskLevel === 'CRITICAL' ? 'var(--color-critical)' : 'var(--color-warning)'};">
              <div class="card-body">
                <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:var(--space-4);flex-wrap:wrap;">
                  <div style="flex:1;min-width:300px;">
                    <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
                      <span class="mono" style="font-weight:700;color:var(--color-navy-900);">${item.id}</span>
                      <span class="badge ${item.riskLevel === 'CRITICAL' ? 'badge-critical' : 'badge-warning'}">${item.riskLevel} RISK</span>
                      <span class="badge badge-neutral mono">${item.transactionId}</span>
                    </div>

                    <h4 style="font-size:16px;color:var(--color-navy-900);margin-bottom:4px;">${escapeHTML(item.actionTitle)}</h4>
                    <p style="font-size:13px;color:var(--color-text-secondary);margin-bottom:12px;">${escapeHTML(item.description)}</p>

                    <!-- AI Justification Box -->
                    <div style="background:var(--color-bg-page);border:1px solid var(--color-border-default);border-radius:var(--radius-md);padding:10px 14px;font-size:12px;margin-bottom:12px;">
                      <strong style="color:var(--color-navy-900);display:flex;align-items:center;gap:6px;margin-bottom:3px;">
                        ${getIcon('cpu')} AI Forensic Recommendation
                      </strong>
                      <span style="color:var(--color-text-secondary);">${escapeHTML(item.justification)}</span>
                    </div>

                    <div style="display:flex;gap:16px;font-size:12px;color:var(--color-text-secondary);">
                      <div><strong>Impact:</strong> ${escapeHTML(item.impact)}</div>
                      <div><strong>Amount:</strong> <span class="tabular-nums font-semibold">${formatCurrency(item.amount, item.currency)}</span></div>
                      <div><strong>Requested By:</strong> ${escapeHTML(item.requestedBy)}</div>
                    </div>
                  </div>

                  <div style="display:flex;gap:10px;align-items:center;">
                    <button class="btn btn-secondary btn-reject-action" data-id="${item.id}">
                      ${getIcon('close')}
                      Reject
                    </button>
                    <button class="btn btn-primary btn-approve-action" data-id="${item.id}">
                      ${getIcon('check')}
                      Approve & Execute
                    </button>
                  </div>
                </div>
              </div>
            </div>
          `).join('')}
        </div>
      `}
    </div>

    <!-- Resolved History Section -->
    ${resolved.length > 0 ? `
      <div>
        <h3 style="font-size:14px;text-transform:uppercase;letter-spacing:0.05em;color:var(--color-text-secondary);margin-bottom:12px;display:flex;align-items:center;gap:6px;">
          ${getIcon('clock')}
          Decided Actions History (${resolved.length})
        </h3>
        <div style="display:flex;flex-direction:column;gap:var(--space-3);">
          ${resolved.map(item => `
            <div class="card" style="opacity:0.85;">
              <div class="card-body" style="padding:14px 20px;display:flex;align-items:center;justify-content:space-between;gap:12px;">
                <div>
                  <div style="display:flex;align-items:center;gap:8px;">
                    <span class="mono" style="font-size:12px;font-weight:600;">${item.id}</span>
                    <span class="badge ${item.status === 'APPROVED' ? 'badge-success' : 'badge-neutral'}">${item.status}</span>
                    <span style="font-size:13px;font-weight:600;color:var(--color-navy-900);">${escapeHTML(item.actionTitle)}</span>
                  </div>
                  <div style="font-size:12px;color:var(--color-text-secondary);margin-top:2px;">
                    Decided by <strong>${escapeHTML(item.decidedBy)}</strong> &bull; Note: "${escapeHTML(item.operatorNote || 'None')}" &bull; ${formatDateTime(item.decidedAt)}
                  </div>
                </div>
                <div class="tabular-nums" style="font-weight:600;font-size:14px;">
                  ${formatCurrency(item.amount, item.currency)}
                </div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    ` : ''}
  `;

  // Attach handlers
  container.querySelectorAll('.btn-approve-action').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      promptDecisionModal(id, 'APPROVE');
    });
  });

  container.querySelectorAll('.btn-reject-action').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      promptDecisionModal(id, 'REJECT');
    });
  });
}

function promptDecisionModal(approvalId, type) {
  const item = store.approvals.find(a => a.id === approvalId);
  if (!item) return;

  pendingActionToDecide = item;
  decisionType = type;

  const modalTitle = document.getElementById('approval-modal-title');
  const modalDesc = document.getElementById('approval-modal-desc');
  const modalConfirmBtn = document.getElementById('btn-confirm-approval');
  const noteInput = document.getElementById('approval-note-input');

  if (modalTitle) {
    modalTitle.textContent = type === 'APPROVE' ? `Confirm Approval: ${item.actionTitle}` : `Reject Action: ${item.actionTitle}`;
  }

  if (modalDesc) {
    modalDesc.innerHTML = `
      <div style="font-size:13px;color:var(--color-text-secondary);">
        <strong>Action:</strong> ${escapeHTML(item.description)}<br/>
        <strong>Transaction:</strong> <span class="mono">${item.transactionId}</span> &bull; <strong>Amount:</strong> ${formatCurrency(item.amount)}<br/>
        <strong>Risk Impact:</strong> ${escapeHTML(item.impact)}
      </div>
    `;
  }

  if (noteInput) {
    noteInput.value = '';
  }

  if (modalConfirmBtn) {
    modalConfirmBtn.className = type === 'APPROVE' ? 'btn btn-primary' : 'btn btn-danger';
    modalConfirmBtn.textContent = type === 'APPROVE' ? 'Execute Simulated Approval' : 'Confirm Rejection';
  }

  openModal('approval-decision-modal');
}

function setupApprovalModal() {
  const confirmBtn = document.getElementById('btn-confirm-approval');
  const cancelBtn = document.getElementById('btn-cancel-approval');
  const noteInput = document.getElementById('approval-note-input');

  if (cancelBtn) {
    cancelBtn.addEventListener('click', () => {
      closeModal('approval-decision-modal');
    });
  }

  if (confirmBtn) {
    confirmBtn.addEventListener('click', () => {
      if (!pendingActionToDecide) return;

      const note = noteInput ? noteInput.value.trim() : '';

      if (decisionType === 'APPROVE') {
        const res = store.approveAction(pendingActionToDecide.id, note);
        if (res.success) {
          showToast(`Approved "${pendingActionToDecide.actionTitle}". Local demo state updated.`, 'success');
        }
      } else {
        const res = store.rejectAction(pendingActionToDecide.id, note);
        if (res.success) {
          showToast(`Rejected "${pendingActionToDecide.actionTitle}". Action blocked.`, 'info');
        }
      }

      closeModal('approval-decision-modal');
      pendingActionToDecide = null;
      decisionType = null;
    });
  }
}
