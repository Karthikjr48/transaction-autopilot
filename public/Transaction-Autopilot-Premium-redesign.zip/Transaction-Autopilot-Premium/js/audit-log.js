/**
 * Transaction-Autopilot — Immutable Audit Log
 * Cryptographic & chronological traceability of AI diagnoses, webhook receipts, and operator decisions
 */

import { store } from './state.js';
import { formatDateTime, exportToCSV, escapeHTML } from './utils.js';
import { getIcon } from './icons.js';

let currentActorFilter = 'ALL';

export function initAuditLogView() {
  setupAuditControls();
  renderAuditLogTable();

  store.subscribe('auditLogsChanged', () => {
    renderAuditLogTable();
  });
}

function setupAuditControls() {
  const actorFilterSelect = document.getElementById('audit-actor-filter');
  if (actorFilterSelect) {
    actorFilterSelect.addEventListener('change', (e) => {
      currentActorFilter = e.target.value;
      renderAuditLogTable();
    });
  }

  const exportBtn = document.getElementById('btn-export-audit-csv');
  if (exportBtn) {
    exportBtn.addEventListener('click', () => {
      const logs = getFilteredAuditLogs();
      const exportData = logs.map(l => ({
        'Log ID': l.id,
        'Timestamp': l.timestamp,
        'Transaction ID': l.transactionId,
        'Action': l.action,
        'Actor': l.actor,
        'Source': l.source,
        'Outcome': l.outcome,
        'Details': l.details
      }));
      exportToCSV('Transaction-Autopilot-AuditLog', exportData);
    });
  }
}

function getFilteredAuditLogs() {
  return store.auditLogs.filter(l => {
    if (currentActorFilter === 'ALL') return true;
    if (currentActorFilter === 'HUMAN') return l.actor.includes('Merchant') || l.actor.includes('Elena');
    if (currentActorFilter === 'AI') return l.actor.includes('AI') || l.actor.includes('Autopilot');
    if (currentActorFilter === 'WEBHOOK') return l.actor.includes('Webhook') || l.actor.includes('Gateway');
    return true;
  });
}

export function renderAuditLogTable() {
  const tbody = document.getElementById('audit-log-tbody');
  const countBadge = document.getElementById('audit-count-badge');
  if (!tbody) return;

  const logs = getFilteredAuditLogs();
  if (countBadge) {
    countBadge.textContent = `${logs.length} entries`;
  }

  tbody.innerHTML = logs.map(l => {
    let outcomeVariant = 'neutral';
    if (l.outcome.includes('APPROVED') || l.outcome.includes('RESOLVED')) outcomeVariant = 'success';
    if (l.outcome.includes('BLOCKED') || l.outcome.includes('FLAGGED')) outcomeVariant = 'critical';
    if (l.outcome.includes('QUEUED')) outcomeVariant = 'warning';

    return `
      <tr>
        <td class="tabular-nums mono" style="font-size:12px;color:var(--color-text-secondary);">
          ${formatDateTime(l.timestamp)}
        </td>
        <td>
          <span class="mono" style="font-weight:600;color:var(--color-navy-900);">${l.transactionId}</span>
        </td>
        <td style="font-weight:600;font-size:13px;color:var(--color-navy-900);">
          ${escapeHTML(l.action)}
        </td>
        <td style="font-size:12px;">
          ${escapeHTML(l.actor)}
        </td>
        <td style="font-size:12px;color:var(--color-text-tertiary);">
          ${escapeHTML(l.source)}
        </td>
        <td>
          <span class="badge badge-${outcomeVariant}"><span class="badge-dot"></span>${l.outcome}</span>
        </td>
        <td style="font-size:12px;color:var(--color-text-secondary);max-width:320px;" class="text-truncate" title="${escapeHTML(l.details)}">
          ${escapeHTML(l.details)}
        </td>
      </tr>
    `;
  }).join('');
}
