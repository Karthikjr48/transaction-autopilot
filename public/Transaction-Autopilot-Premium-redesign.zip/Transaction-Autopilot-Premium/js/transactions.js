/**
 * Transaction-Autopilot — Transactions Explorer
 * Search, multi-criteria filtering, tabular sorting, pagination, and CSV export
 */

import { store } from './state.js';
import { formatCurrency, formatDateTime, exportToCSV, escapeHTML, debounce } from './utils.js';
import { getIcon } from './icons.js';

let currentFilter = 'ALL';
let searchQuery = '';
let currentPage = 1;
const PAGE_SIZE = 10;

export function initTransactionsView() {
  setupFilterControls();
  renderTransactionsTable();

  store.subscribe('transactionsChanged', () => {
    renderTransactionsTable();
  });
}

function setupFilterControls() {
  const searchInput = document.getElementById('trx-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', debounce((e) => {
      searchQuery = e.target.value.trim().toLowerCase();
      currentPage = 1;
      renderTransactionsTable();
    }, 200));
  }

  const filterChips = document.querySelectorAll('.trx-filter-chip');
  filterChips.forEach(chip => {
    chip.addEventListener('click', () => {
      filterChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      currentFilter = chip.getAttribute('data-filter') || 'ALL';
      currentPage = 1;
      renderTransactionsTable();
    });
  });

  const exportBtn = document.getElementById('btn-export-trx-csv');
  if (exportBtn) {
    exportBtn.addEventListener('click', () => {
      const filtered = getFilteredTransactions();
      const exportData = filtered.map(t => ({
        'Transaction ID': t.id,
        'Customer': t.customerName,
        'Email': t.customerEmail,
        'Amount': t.amount,
        'Currency': t.currency,
        'PayPal Status': t.paypalStatus,
        'Store Status': t.merchantStatus,
        'Fulfillment Status': t.fulfillmentStatus,
        'Health': t.overallHealth,
        'Date': t.timestamp
      }));
      exportToCSV('Transaction-Autopilot-Ledger', exportData);
    });
  }
}

function getFilteredTransactions() {
  return store.transactions.filter(t => {
    // Search match
    if (searchQuery) {
      const matchId = t.id.toLowerCase().includes(searchQuery);
      const matchCust = t.customerName.toLowerCase().includes(searchQuery);
      const matchEmail = t.customerEmail.toLowerCase().includes(searchQuery);
      const matchOrder = t.merchantOrderId && t.merchantOrderId.toLowerCase().includes(searchQuery);
      if (!matchId && !matchCust && !matchEmail && !matchOrder) return false;
    }

    // Filter chip match
    if (currentFilter === 'FLAGGED') {
      return t.overallHealth === 'CRITICAL' || t.overallHealth === 'WARNING';
    }
    if (currentFilter === 'COMPLETED') {
      return t.paypalStatus === 'COMPLETED';
    }
    if (currentFilter === 'PENDING') {
      return t.paypalStatus === 'PENDING' || t.fulfillmentStatus === 'NOT_DETECTED';
    }
    if (currentFilter === 'HEALTHY') {
      return t.overallHealth === 'HEALTHY';
    }

    return true;
  });
}

export function renderTransactionsTable() {
  const tbody = document.getElementById('all-transactions-tbody');
  const countBadge = document.getElementById('trx-count-badge');
  if (!tbody) return;

  const filtered = getFilteredTransactions();
  if (countBadge) {
    countBadge.textContent = `${filtered.length} records`;
  }

  if (filtered.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" style="text-align:center;padding:40px;color:var(--color-text-tertiary);">
          ${getIcon('search', 'style="width:32px;height:32px;margin-bottom:8px;color:#94A3B8;"')}
          <div style="font-weight:600;font-size:14px;color:var(--color-navy-900);">No transactions matching criteria</div>
          <p style="font-size:12px;margin-top:4px;">Try adjusting your search query or status filter.</p>
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = filtered.map(t => {
    const isCritical = t.overallHealth === 'CRITICAL';
    const isWarning = t.overallHealth === 'WARNING';
    const rowClass = isCritical ? 'row-flagged' : '';

    return `
      <tr class="${rowClass}" data-trx-id="${t.id}" style="cursor:pointer;">
        <td>
          <div style="display:flex;align-items:center;gap:8px;">
            ${isCritical ? `<span style="color:var(--color-critical);">${getIcon('alertTriangle')}</span>` : ''}
            <div>
              <span class="mono" style="font-weight:600;color:var(--color-navy-900);">${t.id}</span>
              <div style="font-size:11px;color:var(--color-text-tertiary);">${escapeHTML(t.customerName)}</div>
            </div>
          </div>
        </td>
        <td class="tabular-nums" style="font-weight:600;">
          ${formatCurrency(t.amount, t.currency)}
        </td>
        <td>
          ${renderBadge(t.paypalStatus, t.paypalStatus === 'COMPLETED' ? 'success' : (t.paypalStatus === 'REFUNDED' ? 'neutral' : 'warning'))}
        </td>
        <td>
          ${renderBadge(t.merchantStatus, t.merchantStatus === 'FULFILLED' ? 'success' : (t.merchantStatus === 'CANCELED' ? 'critical' : 'neutral'))}
        </td>
        <td>
          ${renderFulfillmentBadge(t.fulfillmentStatus)}
        </td>
        <td style="color:var(--color-text-secondary);font-size:12px;" class="tabular-nums">
          ${formatDateTime(t.timestamp)}
        </td>
        <td style="text-align:right;">
          <button class="btn btn-sm btn-secondary btn-investigate-row" data-id="${t.id}">
            ${getIcon('investigations')}
            Investigate
          </button>
        </td>
      </tr>
    `;
  }).join('');

  // Row selection handler
  tbody.querySelectorAll('.btn-investigate-row').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = btn.getAttribute('data-id');
      store.setSelectedTransaction(id);
      store.setView('investigations');
    });
  });

  tbody.querySelectorAll('tr').forEach(row => {
    row.addEventListener('click', () => {
      const id = row.getAttribute('data-trx-id');
      if (id) {
        store.setSelectedTransaction(id);
        store.setView('investigations');
      }
    });
  });
}

function renderBadge(text, variant) {
  return `<span class="badge badge-${variant}"><span class="badge-dot"></span>${text}</span>`;
}

function renderFulfillmentBadge(status) {
  if (status === 'DELIVERED' || status === 'IN_TRANSIT') {
    return `<span class="badge badge-success"><span class="badge-dot"></span>${status}</span>`;
  }
  if (status === 'NOT_DETECTED') {
    return `<span class="badge badge-critical pulse-badge"><span class="badge-dot"></span>NOT DETECTED</span>`;
  }
  if (status === 'DISPATCH_QUEUED') {
    return `<span class="badge badge-info"><span class="badge-dot"></span>DISPATCH QUEUED</span>`;
  }
  return `<span class="badge badge-warning"><span class="badge-dot"></span>${status}</span>`;
}
