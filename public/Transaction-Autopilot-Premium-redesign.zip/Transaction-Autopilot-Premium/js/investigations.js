/**
 * Transaction-Autopilot — AI Investigation Workspace
 * The core product workspace: 3-Way Reconciliation, Event Timeline, Fact vs Hypothesis Diagnosis, and Safe Recovery Protocol
 */

import { store } from './state.js';
import { formatCurrency, formatDateTime, escapeHTML, showToast, openModal } from './utils.js';
import { getIcon } from './icons.js';

export function initInvestigationsView() {
  renderInvestigationWorkspace();

  store.subscribe('transactionSelected', () => {
    renderInvestigationWorkspace();
  });

  store.subscribe('transactionsChanged', () => {
    renderInvestigationWorkspace();
  });
}

export function renderInvestigationWorkspace() {
  const container = document.getElementById('investigation-workspace');
  if (!container) return;

  const trx = store.getSelectedTransaction();
  if (!trx) {
    container.innerHTML = `<div style="padding:40px;text-align:center;">No transaction selected.</div>`;
    return;
  }

  const isFlagged = trx.overallHealth === 'CRITICAL' || trx.overallHealth === 'WARNING';

  container.innerHTML = `
    <!-- Top Summary Banner -->
    <div class="card" style="margin-bottom:var(--space-6);">
      <div class="card-body" style="display:flex;align-items:center;justify-content:space-between;gap:var(--space-4);flex-wrap:wrap;">
        <div style="display:flex;align-items:center;gap:var(--space-4);">
          <div style="width:48px;height:48px;border-radius:var(--radius-md);background:${isFlagged ? 'var(--color-critical-bg)' : 'var(--color-success-bg)'};color:${isFlagged ? 'var(--color-critical)' : 'var(--color-success)'};display:flex;align-items:center;justify-content:center;">
            ${getIcon(isFlagged ? 'alertTriangle' : 'checkCircle')}
          </div>
          <div>
            <div style="display:flex;align-items:center;gap:10px;">
              <h2 style="font-size:20px;font-weight:700;" class="mono">${trx.id}</h2>
              <span class="badge ${isFlagged ? 'badge-critical' : 'badge-success'}">${trx.overallHealth}</span>
              <span class="badge badge-neutral">${trx.environment}</span>
            </div>
            <p style="font-size:13px;color:var(--color-text-secondary);margin-top:2px;">
              Customer: <strong>${escapeHTML(trx.customerName)}</strong> &bull; ${escapeHTML(trx.customerEmail)} &bull; Source: ${trx.dataSource}
            </p>
          </div>
        </div>

        <div style="display:flex;align-items:center;gap:var(--space-5);">
          <div style="text-align:right;">
            <div style="font-size:12px;color:var(--color-text-tertiary);text-transform:uppercase;font-weight:600;">Amount Settled</div>
            <div style="font-size:22px;font-weight:700;color:var(--color-navy-900);" class="tabular-nums">${formatCurrency(trx.amount, trx.currency)}</div>
          </div>
          <div style="height:40px;width:1px;background:var(--color-border-default);"></div>
          <div style="text-align:right;">
            <div style="font-size:12px;color:var(--color-text-tertiary);text-transform:uppercase;font-weight:600;">Captured At</div>
            <div style="font-size:14px;color:var(--color-navy-900);font-weight:600;" class="tabular-nums">${formatDateTime(trx.timestamp)}</div>
          </div>
        </div>
      </div>
    </div>

    <!-- 3-Way State Reconciliation Matrix -->
    <div style="margin-bottom:var(--space-2);">
      <h3 style="font-size:14px;text-transform:uppercase;letter-spacing:0.05em;color:var(--color-text-secondary);margin-bottom:12px;display:flex;align-items:center;gap:8px;">
        ${getIcon('layers')}
        3-Way State Reconciliation Matrix
      </h3>
    </div>
    <div class="reconciliation-matrix">
      <!-- PayPal State -->
      <div class="recon-node state-${trx.paypalStatus === 'COMPLETED' ? 'success' : 'warning'}">
        <div class="recon-node-header">
          <span class="recon-system-title">${getIcon('dollar')} 1. PayPal Payment</span>
          <span class="badge ${trx.paypalStatus === 'COMPLETED' ? 'badge-success' : 'badge-warning'}">${trx.paypalStatus}</span>
        </div>
        <div class="recon-status-large">${trx.paypalStatus === 'COMPLETED' ? 'Captured & Cleared' : trx.paypalStatus}</div>
        <div class="recon-detail-row">
          <span>Capture Ref:</span>
          <span class="recon-detail-val">${trx.paypalCaptureId || 'None'}</span>
        </div>
        <div class="recon-detail-row">
          <span>Settlement Amount:</span>
          <span class="recon-detail-val tabular-nums">${formatCurrency(trx.amount, trx.currency)}</span>
        </div>
        <div class="recon-detail-row">
          <span>Authorization State:</span>
          <span class="recon-detail-val">HONORED</span>
        </div>
      </div>

      <!-- Merchant Store State -->
      <div class="recon-node state-${trx.merchantStatus === 'FULFILLED' ? 'success' : (trx.merchantStatus === 'CANCELED' ? 'critical' : 'warning')}">
        <div class="recon-node-header">
          <span class="recon-system-title">${getIcon('database')} 2. Store Order</span>
          <span class="badge ${trx.merchantStatus === 'FULFILLED' ? 'badge-success' : (trx.merchantStatus === 'CANCELED' ? 'badge-critical' : 'badge-neutral')}">${trx.merchantStatus}</span>
        </div>
        <div class="recon-status-large">${trx.merchantStatus}</div>
        <div class="recon-detail-row">
          <span>Order Number:</span>
          <span class="recon-detail-val">${trx.merchantOrderId || 'None'}</span>
        </div>
        <div class="recon-detail-row">
          <span>Payment Sync:</span>
          <span class="recon-detail-val">ACKNOWLEDGED</span>
        </div>
        <div class="recon-detail-row">
          <span>Inventory Lock:</span>
          <span class="recon-detail-val">ALLOCATED</span>
        </div>
      </div>

      <!-- Fulfillment State -->
      <div class="recon-node state-${trx.fulfillmentStatus === 'DELIVERED' || trx.fulfillmentStatus === 'IN_TRANSIT' ? 'success' : 'critical'}">
        <div class="recon-node-header">
          <span class="recon-system-title">${getIcon('shield')} 3. Fulfillment Pipeline</span>
          <span class="badge ${trx.fulfillmentStatus === 'NOT_DETECTED' ? 'badge-critical' : 'badge-success'}">${trx.fulfillmentStatus}</span>
        </div>
        <div class="recon-status-large" style="color:${trx.fulfillmentStatus === 'NOT_DETECTED' ? 'var(--color-critical)' : 'inherit'};">
          ${trx.fulfillmentStatus === 'NOT_DETECTED' ? 'Missing / Stalled' : trx.fulfillmentStatus}
        </div>
        <div class="recon-detail-row">
          <span>3PL Webhook Status:</span>
          <span class="recon-detail-val" style="color:${trx.fulfillmentStatus === 'NOT_DETECTED' ? 'var(--color-critical)' : 'inherit'};">
            ${trx.fulfillmentStatus === 'NOT_DETECTED' ? 'UNRECEIVED (36h)' : 'VERIFIED'}
          </span>
        </div>
        <div class="recon-detail-row">
          <span>Carrier Tracking:</span>
          <span class="recon-detail-val">${trx.fulfillmentStatus === 'NOT_DETECTED' ? 'UNASSIGNED' : 'IN_TRANSIT'}</span>
        </div>
        <div class="recon-detail-row">
          <span>Delivery Promise:</span>
          <span class="recon-detail-val" style="color:${trx.fulfillmentStatus === 'NOT_DETECTED' ? 'var(--color-critical)' : 'inherit'};">
            ${trx.fulfillmentStatus === 'NOT_DETECTED' ? 'AT RISK' : 'ON TRACK'}
          </span>
        </div>
      </div>
    </div>

    <!-- Main Investigation Grid: Timeline + AI Diagnosis -->
    <div class="investigation-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:var(--space-6);margin-bottom:var(--space-6);">
      <!-- Left: Event Timeline -->
      <div class="card">
        <div class="card-header">
          <div class="card-title">
            ${getIcon('clock')}
            Event Timeline & Evidence Trail
          </div>
          <span class="badge badge-neutral">${trx.events ? trx.events.length : 0} recorded events</span>
        </div>
        <div class="card-body">
          <div class="timeline-container">
            ${renderTimelineEvents(trx.events || [])}
          </div>
        </div>
      </div>

      <!-- Right: AI Diagnostic Analysis & Recovery Protocol -->
      <div style="display:flex;flex-direction:column;gap:var(--space-6);">
        ${renderAIDiagnosisCard(trx)}
        ${renderRecoveryProtocolCard(trx)}
      </div>
    </div>
  `;

  attachInvestigationEventListeners(trx);
}

function renderTimelineEvents(events) {
  if (!events.length) {
    return `<p style="font-size:13px;color:var(--color-text-tertiary);">No milestone events recorded.</p>`;
  }

  return events.map(evt => {
    let markerClass = 'verified';
    let icon = getIcon('check');

    if (evt.status === 'MISSING') {
      markerClass = 'missing';
      icon = getIcon('alertTriangle');
    } else if (evt.status === 'PENDING') {
      markerClass = 'pending';
      icon = getIcon('clock');
    }

    return `
      <div class="timeline-event">
        <div class="timeline-marker ${markerClass}">
          ${icon}
        </div>
        <div class="timeline-body">
          <div class="timeline-meta">
            <span class="timeline-title">${escapeHTML(evt.title)}</span>
            <span class="timeline-time">${evt.timestamp ? formatDateTime(evt.timestamp) : 'EXPECTED / NOT RECORDED'}</span>
          </div>
          <div style="font-size:11px;color:var(--color-brand-primary);font-weight:600;margin-bottom:4px;">
            Source: ${escapeHTML(evt.system)}
          </div>
          <div class="timeline-desc">
            ${escapeHTML(evt.details)}
          </div>
          ${evt.payload ? `
            <details style="margin-top:8px;">
              <summary style="font-size:11px;color:var(--color-text-muted);cursor:pointer;user-select:none;">View Raw Payload Event</summary>
              <pre style="margin-top:6px;font-size:11px;overflow-x:auto;">${escapeHTML(JSON.stringify(evt.payload, null, 2))}</pre>
            </details>
          ` : ''}
        </div>
      </div>
    `;
  }).join('');
}

function renderAIDiagnosisCard(trx) {
  if (!trx.aiDiagnosis) {
    return `
      <div class="card">
        <div class="card-header">
          <div class="card-title">${getIcon('cpu')} AI Forensic Diagnosis</div>
        </div>
        <div class="card-body" style="text-align:center;padding:30px;color:var(--color-text-tertiary);">
          ${getIcon('checkCircle', 'style="width:36px;height:36px;color:var(--color-success);margin-bottom:8px;"')}
          <div style="font-size:14px;font-weight:600;color:var(--color-navy-900);">Transaction in Nominal Healthy State</div>
          <p style="font-size:12px;margin-top:4px;">No cross-system inconsistency detected across PayPal and merchant fulfillment layers.</p>
        </div>
      </div>
    `;
  }

  const diag = trx.aiDiagnosis;

  return `
    <div class="ai-diagnosis-card">
      <div class="ai-diagnosis-header">
        <div style="display:flex;align-items:center;gap:10px;">
          <div class="ai-badge-engine">
            ${getIcon('cpu')}
            Autopilot Inconsistency Engine v2
          </div>
          <strong style="font-size:14px;">Forensic Synthesis</strong>
        </div>
        <div class="confidence-indicator">
          <span>Confidence:</span>
          <div class="confidence-bar">
            <div class="confidence-fill" style="width:${diag.confidence}%;"></div>
          </div>
          <strong class="tabular-nums" style="color:#FFFFFF;">${diag.confidence}%</strong>
        </div>
      </div>

      <div style="padding:var(--space-4) var(--space-5);background:var(--color-bg-page);border-bottom:1px solid var(--color-border-default);">
        <div style="font-size:14px;font-weight:700;color:var(--color-navy-900);">${escapeHTML(diag.headline)}</div>
        <p style="font-size:12px;color:var(--color-text-secondary);margin-top:4px;">
          ${escapeHTML(diag.confidenceRationale)}
        </p>
      </div>

      <!-- Verified Facts -->
      <div class="ai-section-box">
        <div class="ai-section-title facts">
          ${getIcon('checkCircle')}
          Authoritative Verified Facts
        </div>
        <ul class="ai-list">
          ${diag.verifiedFacts.map(f => `<li class="ai-list-item">${escapeHTML(f)}</li>`).join('')}
        </ul>
      </div>

      <!-- Hypotheses -->
      <div class="ai-section-box">
        <div class="ai-section-title hypotheses">
          ${getIcon('alertTriangle')}
          Plausible Root-Cause Hypotheses
        </div>
        <ul class="ai-list">
          ${diag.hypotheses.map(h => `<li class="ai-list-item">${escapeHTML(h)}</li>`).join('')}
        </ul>
      </div>

      <!-- Missing Information -->
      <div class="ai-section-box" style="border-bottom:none;">
        <div class="ai-section-title missing">
          ${getIcon('alertCircle')}
          Missing Information Needed for Full Closure
        </div>
        <ul class="ai-list">
          ${diag.missingInformation.map(m => `<li class="ai-list-item">${escapeHTML(m)}</li>`).join('')}
        </ul>
      </div>
    </div>
  `;
}

function renderRecoveryProtocolCard(trx) {
  if (!trx.aiDiagnosis || !trx.aiDiagnosis.recommendedRecovery) {
    return '';
  }

  const steps = trx.aiDiagnosis.recommendedRecovery;

  return `
    <div class="card">
      <div class="card-header">
        <div class="card-title">
          ${getIcon('shield')}
          Safe Recovery Protocol
        </div>
        <span class="badge badge-neutral">Human Approval Enforced for Mutations</span>
      </div>
      <div class="card-body">
        <div class="recovery-step-list">
          ${steps.map(s => `
            <div class="recovery-step-item">
              <div class="recovery-step-info">
                <div class="step-number">${s.step}</div>
                <div>
                  <div class="step-text">${escapeHTML(s.title)}</div>
                  <div class="step-tag">
                    ${s.requiresApproval ? '<span style="color:var(--color-critical);font-weight:600;">Requires Human Operator Approval</span>' : 'Safe Automated Read Query'}
                  </div>
                </div>
              </div>
              <div>
                ${s.requiresApproval ? `
                  <button class="btn btn-sm btn-primary btn-queue-action" data-trx="${trx.id}" data-title="${escapeHTML(s.title)}">
                    ${getIcon('shield')}
                    Review in Approval Queue
                  </button>
                ` : `
                  <button class="btn btn-sm btn-secondary btn-run-query" data-step="${s.step}">
                    ${getIcon('refresh')}
                    Query Now
                  </button>
                `}
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    </div>
  `;
}

function attachInvestigationEventListeners(trx) {
  // Safe probe execution simulation
  document.querySelectorAll('.btn-run-query').forEach(btn => {
    btn.addEventListener('click', () => {
      btn.innerHTML = `${getIcon('refresh')} Querying...`;
      btn.disabled = true;
      setTimeout(() => {
        btn.innerHTML = `${getIcon('check')} Query Verified`;
        showToast('3PL Endpoint responded HTTP 200: Order #ORD-84920 found in un-batched state.', 'info');
      }, 700);
    });
  });

  // Sensitive action trigger: navigate to Approval Queue
  document.querySelectorAll('.btn-queue-action').forEach(btn => {
    btn.addEventListener('click', () => {
      store.setView('approvals');
    });
  });
}
