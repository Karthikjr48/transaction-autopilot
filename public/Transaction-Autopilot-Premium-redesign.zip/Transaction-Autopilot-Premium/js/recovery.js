/**
 * Transaction-Autopilot — Recovery Center
 * Prioritized recovery playbooks, stuck order triage, and resolution state tracking
 */

import { store } from './state.js';
import { formatCurrency, escapeHTML, showToast } from './utils.js';
import { getIcon } from './icons.js';

export function initRecoveryView() {
  renderRecoveryCenter();

  store.subscribe('transactionsChanged', () => {
    renderRecoveryCenter();
  });

  store.subscribe('approvalsChanged', () => {
    renderRecoveryCenter();
  });
}

export function renderRecoveryCenter() {
  const container = document.getElementById('recovery-center-content');
  if (!container) return;

  const flaggedTrx = store.transactions.filter(t => t.overallHealth !== 'HEALTHY');
  const totalAtRiskRevenue = flaggedTrx.reduce((acc, t) => acc + (t.amount || 0), 0);

  container.innerHTML = `
    <!-- Top Summary Banner -->
    <div class="card" style="margin-bottom:var(--space-6);">
      <div class="card-body" style="display:flex;align-items:center;justify-content:space-between;gap:var(--space-4);flex-wrap:wrap;">
        <div>
          <h2 style="font-size:18px;font-weight:700;color:var(--color-navy-900);">Active Recovery Playbooks</h2>
          <p style="font-size:13px;color:var(--color-text-secondary);margin-top:2px;">
            AI-detected cross-system discrepancies queued for automated probe or human sign-off.
          </p>
        </div>
        <div style="display:flex;align-items:center;gap:var(--space-4);">
          <div style="text-align:right;">
            <div style="font-size:12px;color:var(--color-text-tertiary);text-transform:uppercase;font-weight:600;">At-Risk Revenue</div>
            <div style="font-size:22px;font-weight:700;color:var(--color-critical);" class="tabular-nums">
              ${formatCurrency(totalAtRiskRevenue)}
            </div>
          </div>
          <button class="btn btn-secondary" id="btn-batch-reconcile">
            ${getIcon('refresh')}
            Run Batch Sync Probe
          </button>
        </div>
      </div>
    </div>

    <!-- Playbook Cards -->
    <div style="display:flex;flex-direction:column;gap:var(--space-4);">
      ${flaggedTrx.map(trx => {
        const isCritical = trx.overallHealth === 'CRITICAL';
        return `
          <div class="card" style="border-left:4px solid ${isCritical ? 'var(--color-critical)' : 'var(--color-warning)'};">
            <div class="card-body" style="display:flex;align-items:flex-start;justify-content:space-between;gap:var(--space-4);flex-wrap:wrap;">
              <div style="flex:1;min-width:280px;">
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
                  <span class="mono" style="font-size:14px;font-weight:700;color:var(--color-navy-900);">${trx.id}</span>
                  <span class="badge ${isCritical ? 'badge-critical' : 'badge-warning'}">${trx.overallHealth}</span>
                  <span class="badge badge-neutral">${trx.discrepancyType}</span>
                </div>
                <h4 style="font-size:15px;color:var(--color-navy-900);margin-bottom:4px;">${escapeHTML(trx.discrepancyTitle)}</h4>
                <p style="font-size:13px;color:var(--color-text-secondary);">${escapeHTML(trx.discrepancySummary)}</p>

                <div style="margin-top:12px;display:flex;gap:16px;font-size:12px;color:var(--color-text-secondary);">
                  <div><strong>Customer:</strong> ${escapeHTML(trx.customerName)}</div>
                  <div><strong>Amount:</strong> <span class="tabular-nums font-semibold">${formatCurrency(trx.amount, trx.currency)}</span></div>
                  <div><strong>PayPal Status:</strong> ${trx.paypalStatus}</div>
                  <div><strong>Fulfillment:</strong> <span style="color:${trx.fulfillmentStatus === 'NOT_DETECTED' ? 'var(--color-critical)' : 'inherit'};font-weight:600;">${trx.fulfillmentStatus}</span></div>
                </div>
              </div>

              <div style="display:flex;flex-direction:column;gap:8px;align-items:flex-end;">
                <button class="btn btn-primary btn-open-trx-investigation" data-id="${trx.id}">
                  ${getIcon('investigations')}
                  Open Investigation
                </button>
                <button class="btn btn-secondary btn-jump-approval" data-id="${trx.id}">
                  ${getIcon('shield')}
                  Check Approval Queue
                </button>
              </div>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;

  // Attach button events
  const batchBtn = document.getElementById('btn-batch-reconcile');
  if (batchBtn) {
    batchBtn.addEventListener('click', () => {
      batchBtn.disabled = true;
      batchBtn.innerHTML = `${getIcon('refresh')} Probing Endpoints...`;
      setTimeout(() => {
        batchBtn.disabled = false;
        batchBtn.innerHTML = `${getIcon('refresh')} Run Batch Sync Probe`;
        showToast('Batch probe completed across PayPal Orders API and Shopify Webhook Log. 14 records verified.', 'success');
      }, 900);
    });
  }

  container.querySelectorAll('.btn-open-trx-investigation').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      store.setSelectedTransaction(id);
      store.setView('investigations');
    });
  });

  container.querySelectorAll('.btn-jump-approval').forEach(btn => {
    btn.addEventListener('click', () => {
      store.setView('approvals');
    });
  });
}
