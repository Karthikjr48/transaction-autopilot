/**
 * Configuration & Environment Validation — Transaction-Autopilot
 * Validates environment variables, credentials, and service settings.
 * Enforces strict zero-leak policies for secrets.
 */

import crypto from 'crypto';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootEnvPath = path.resolve(__dirname, '..', '.env');
dotenv.config({ path: rootEnvPath });

// Secure resolution of Operator Key without static fallback
function resolveOperatorKey() {
  const envKey = process.env.OPERATOR_SECRET_KEY;
  if (envKey && envKey.trim()) {
    return envKey.trim();
  }
  if (process.env.NODE_ENV === 'production') {
    throw new Error('OPERATOR_SECRET_KEY environment variable is strictly required in production.');
  }
  const generatedKey = crypto.randomBytes(32).toString('hex');
  console.warn('[SECURITY WARNING] OPERATOR_SECRET_KEY not set in environment. Generated ephemeral key for session.');
  return generatedKey;
}

export const config = {
  // Network Ports & URLs
  port: parseInt(process.env.PORT || '5000', 10),
  uiPort: parseInt(process.env.UI_PORT || '3000', 10),
  backendUrl: process.env.BACKEND_URL || 'http://localhost:5000',
  uiClientUrl: process.env.UI_CLIENT_URL || 'http://localhost:3000',

  // PayPal Sandbox Configuration
  paypal: {
    mode: (process.env.PAYPAL_MODE || 'sandbox').toLowerCase(),
    clientId: process.env.PAYPAL_CLIENT_ID || '',
    clientSecret: process.env.PAYPAL_CLIENT_SECRET || '',
    baseUrl: (process.env.PAYPAL_MODE || 'sandbox').toLowerCase() === 'live'
      ? 'https://api-m.paypal.com'
      : 'https://api-m.sandbox.paypal.com',
    webBaseUrl: (process.env.PAYPAL_MODE || 'sandbox').toLowerCase() === 'live'
      ? 'https://www.paypal.com'
      : 'https://www.sandbox.paypal.com'
  },

  // Groq AI Configuration
  groq: {
    apiKey: process.env.GROQ_API_KEY || '',
    model: process.env.GROQ_MODEL || 'qwen/qwen3.8-27b'
  },

  // Operations Console & Backend Authorization Secret
  operations: {
    secretKey: resolveOperatorKey(),
    tokenExpiryHours: 24
  },

  // Merchant Account Configuration
  merchant: {
    email: process.env.MERCHANT_EMAIL || 'merchant@transaction-autopilot.local',
    password: process.env.MERCHANT_PASSWORD || 'MerchantSecure2026!'
  },

  // Email & Invoice Delivery Provider Configuration
  email: {
    provider: (process.env.EMAIL_PROVIDER || 'brevo').toLowerCase(), // 'brevo', 'smtp', 'test_provider', 'none'
    smtpHost: process.env.SMTP_HOST || (process.env.EMAIL_PROVIDER === 'brevo' ? 'smtp-relay.brevo.com' : ''),
    smtpPort: parseInt(process.env.SMTP_PORT || '587', 10),
    smtpSecure: process.env.SMTP_SECURE === 'true',
    smtpUser: process.env.SMTP_USER || '',
    smtpPass: process.env.SMTP_PASS || '',
    fromAddress: process.env.EMAIL_FROM || 'notifications@merchant.local'
  }
};

/**
 * Validate core configuration without leaking secrets
 */
export function validateEnvironment() {
  const issues = [];

  if (!config.paypal.clientId) {
    issues.push('PAYPAL_CLIENT_ID is missing');
  }
  if (!config.paypal.clientSecret) {
    issues.push('PAYPAL_CLIENT_SECRET is missing');
  }
  if (!config.groq.apiKey) {
    issues.push('GROQ_API_KEY is missing');
  }

  // Validate Brevo SMTP if provider is brevo
  if (config.email.provider === 'brevo') {
    if (!config.email.smtpUser) {
      issues.push('SMTP_USER is missing for Brevo SMTP');
    }
    if (!config.email.smtpPass) {
      issues.push('SMTP_PASS is missing for Brevo SMTP');
    }
    if (!config.email.fromAddress) {
      issues.push('EMAIL_FROM is missing for Brevo SMTP');
    }
  }

  return {
    valid: issues.length === 0,
    issues,
    summary: {
      port: config.port,
      uiPort: config.uiPort,
      paypalMode: config.paypal.mode,
      paypalBaseUrl: config.paypal.baseUrl,
      groqModel: config.groq.model,
      emailProvider: config.email.provider,
      hasPayPalClientSecret: Boolean(config.paypal.clientSecret),
      hasGroqApiKey: Boolean(config.groq.apiKey)
    }
  };
}

export default config;
