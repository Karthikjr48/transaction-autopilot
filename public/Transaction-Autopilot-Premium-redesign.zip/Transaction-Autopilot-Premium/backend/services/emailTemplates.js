/**
 * Email Templates Module — Transaction-Autopilot
 * Professional, responsive HTML templates with plain-text alternatives.
 * Strictly escapes all dynamic variables to prevent HTML/XSS injection.
 */

/**
 * Escape HTML special characters
 */
export function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Base email layout wrapper
 */
function wrapLayout({ title, previewText, bodyContent }) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(title)}</title>
  <style>
    body { margin: 0; padding: 0; background-color: #F5F7FA; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; -webkit-font-smoothing: antialiased; color: #1C2430; }
    table { border-collapse: collapse; }
    .container { max-width: 600px; margin: 0 auto; background-color: #FFFFFF; border-radius: 8px; overflow: hidden; border: 1px solid #E1E7EE; }
    .header { background-color: #003087; padding: 28px 32px; text-align: left; }
    .logo-text { color: #FFFFFF; font-size: 20px; font-weight: 700; letter-spacing: -0.5px; margin: 0; }
    .content { padding: 36px 32px; line-height: 1.6; }
    h1 { font-size: 22px; font-weight: 700; color: #1C2430; margin: 0 0 16px 0; }
    p { font-size: 15px; color: #4B5563; margin: 0 0 18px 0; }
    .card { background-color: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 6px; padding: 20px; margin: 24px 0; }
    .row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #EDF2F7; font-size: 14px; }
    .row:last-child { border-bottom: none; }
    .label { color: #64748B; font-weight: 500; }
    .value { color: #0F172A; font-weight: 600; text-align: right; }
    .btn { display: inline-block; background-color: #0070BA; color: #FFFFFF !important; text-decoration: none; padding: 12px 28px; border-radius: 6px; font-weight: 600; font-size: 15px; margin: 18px 0 8px 0; }
    .btn-secondary { background-color: #F1F5F9; color: #0F172A !important; border: 1px solid #CBD5E1; }
    .badge-success { background-color: #DEF7EC; color: #03543F; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 600; }
    .badge-warning { background-color: #FEF3C7; color: #92400E; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 600; }
    .badge-danger { background-color: #FDE8E8; color: #9B1C1C; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 600; }
    .footer { background-color: #F8FAFC; padding: 24px 32px; font-size: 12px; color: #94A3B8; text-align: center; border-top: 1px solid #E2E8F0; }
  </style>
</head>
<body>
  <div style="display:none;font-size:1px;color:#333;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;">
    ${escapeHtml(previewText)}
  </div>
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #F5F7FA; padding: 32px 16px;">
    <tr>
      <td align="center">
        <table class="container" width="100%" cellpadding="0" cellspacing="0">
          <tr>
            <td class="header">
              <div class="logo-text">Transaction-Autopilot</div>
            </td>
          </tr>
          <tr>
            <td class="content">
              ${bodyContent}
            </td>
          </tr>
          <tr>
            <td class="footer">
              <p style="margin: 0; font-size: 12px; color: #94A3B8;">
                This transactional email was delivered via Brevo SMTP on behalf of your merchant.
                <br>If you have questions about your order, please reply directly to this notification.
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

/**
 * 1. Payment Captured Email Template
 */
export function buildPaymentCapturedTemplate({
  orderRef,
  customerName,
  itemDescription,
  amountDisplay,
  timestamp,
  merchantName = 'Merchant Store'
}) {
  const safeName = customerName ? escapeHtml(customerName) : 'Valued Customer';
  const safeRef = escapeHtml(orderRef);
  const safeDesc = escapeHtml(itemDescription || 'Order Payment');
  const safeAmount = escapeHtml(amountDisplay || '');
  const safeDate = escapeHtml(timestamp || new Date().toUTCString());

  const subject = `Payment Confirmed: Order ${safeRef}`;
  const previewText = `Your payment for order ${safeRef} was successfully processed.`;

  const html = wrapLayout({
    title: subject,
    previewText,
    bodyContent: `
      <h1>Payment Confirmation</h1>
      <p>Hello ${safeName},</p>
      <p>Your payment has been successfully authorized and captured. Your order has been placed into our fulfillment pipeline.</p>
      
      <table class="card" width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td style="padding: 6px 0;" class="label">Order Reference</td>
          <td style="padding: 6px 0;" class="value">${safeRef}</td>
        </tr>
        <tr>
          <td style="padding: 6px 0;" class="label">Payment Status</td>
          <td style="padding: 6px 0;" class="value"><span class="badge-success">COMPLETED</span></td>
        </tr>
        <tr>
          <td style="padding: 6px 0;" class="label">Item / Service</td>
          <td style="padding: 6px 0;" class="value">${safeDesc}</td>
        </tr>
        ${safeAmount ? `
        <tr>
          <td style="padding: 6px 0;" class="label">Amount Paid</td>
          <td style="padding: 6px 0;" class="value">${safeAmount}</td>
        </tr>` : ''}
        <tr>
          <td style="padding: 6px 0;" class="label">Timestamp</td>
          <td style="padding: 6px 0;" class="value">${safeDate}</td>
        </tr>
      </table>

      <p>Thank you for your business. We will update you with tracking information as soon as your order ships.</p>
    `
  });

  const text = `PAYMENT CONFIRMATION\n\nHello ${safeName},\n\nYour payment for order ${safeRef} has been successfully captured.\nStatus: COMPLETED\nItem: ${safeDesc}\n${safeAmount ? `Amount: ${safeAmount}\n` : ''}Date: ${safeDate}\n\nThank you for your business!`;

  return { subject, html, text };
}

/**
 * 2. Payment Failed Email Template
 */
export function buildPaymentFailedTemplate({
  orderRef,
  customerName,
  checkoutUrl,
  reason,
  timestamp
}) {
  const safeName = customerName ? escapeHtml(customerName) : 'Valued Customer';
  const safeRef = escapeHtml(orderRef);
  const safeReason = escapeHtml(reason || 'The payment authorization could not be completed by PayPal.');
  const safeUrl = checkoutUrl ? escapeHtml(checkoutUrl) : null;
  const safeDate = escapeHtml(timestamp || new Date().toUTCString());

  const subject = `Payment Notice: Action Required for Order ${safeRef}`;
  const previewText = `We were unable to process your payment for order ${safeRef}. Please review your payment details.`;

  const html = wrapLayout({
    title: subject,
    previewText,
    bodyContent: `
      <h1>Payment Authorization Notice</h1>
      <p>Hello ${safeName},</p>
      <p>We were unable to complete the payment authorization for your order <strong>${safeRef}</strong>.</p>
      
      <table class="card" width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td style="padding: 6px 0;" class="label">Order Reference</td>
          <td style="padding: 6px 0;" class="value">${safeRef}</td>
        </tr>
        <tr>
          <td style="padding: 6px 0;" class="label">Status</td>
          <td style="padding: 6px 0;" class="value"><span class="badge-danger">FAILED / DECLINED</span></td>
        </tr>
        <tr>
          <td style="padding: 6px 0;" class="label">Notice</td>
          <td style="padding: 6px 0;" class="value">${safeReason}</td>
        </tr>
        <tr>
          <td style="padding: 6px 0;" class="label">Timestamp</td>
          <td style="padding: 6px 0;" class="value">${safeDate}</td>
        </tr>
      </table>

      <p>No funds were charged to your account. You can complete your purchase or choose another payment method using the link below:</p>

      ${safeUrl ? `
      <div style="text-align: center; margin: 24px 0;">
        <a href="${safeUrl}" class="btn">Retry Payment on PayPal</a>
      </div>` : ''}

      <p>If you believe this is an error, please check with your financial institution or reply to this message for assistance.</p>
    `
  });

  const text = `PAYMENT AUTHORIZATION NOTICE\n\nHello ${safeName},\n\nWe were unable to complete payment for order ${safeRef}.\nStatus: FAILED / DECLINED\nReason: ${safeReason}\nDate: ${safeDate}\n\n${safeUrl ? `You can retry your payment here: ${safeUrl}\n\n` : ''}Please contact support if you need assistance.`;

  return { subject, html, text };
}

/**
 * 3. Invoice Created Email Template
 */
export function buildInvoiceCreatedTemplate({
  invoiceNumber,
  customerName,
  itemDescription,
  amountDisplay,
  checkoutUrl,
  notes,
  timestamp
}) {
  const safeName = customerName ? escapeHtml(customerName) : 'Valued Customer';
  const safeInv = escapeHtml(invoiceNumber);
  const safeDesc = escapeHtml(itemDescription || 'Invoice for Services');
  const safeAmount = escapeHtml(amountDisplay || '');
  const safeUrl = checkoutUrl ? escapeHtml(checkoutUrl) : null;
  const safeNotes = notes ? escapeHtml(notes) : null;
  const safeDate = escapeHtml(timestamp || new Date().toUTCString());

  const subject = `Invoice ${safeInv} from Transaction-Autopilot`;
  const previewText = `New invoice ${safeInv} is ready for payment.`;

  const html = wrapLayout({
    title: subject,
    previewText,
    bodyContent: `
      <h1>Invoice Ready for Payment</h1>
      <p>Hello ${safeName},</p>
      <p>A new invoice has been issued to your account. You can review the details below and pay securely via PayPal.</p>
      
      <table class="card" width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td style="padding: 6px 0;" class="label">Invoice Number</td>
          <td style="padding: 6px 0;" class="value">${safeInv}</td>
        </tr>
        <tr>
          <td style="padding: 6px 0;" class="label">Description</td>
          <td style="padding: 6px 0;" class="value">${safeDesc}</td>
        </tr>
        ${safeAmount ? `
        <tr>
          <td style="padding: 6px 0;" class="label">Total Due</td>
          <td style="padding: 6px 0;" class="value">${safeAmount}</td>
        </tr>` : ''}
        <tr>
          <td style="padding: 6px 0;" class="label">Issued Date</td>
          <td style="padding: 6px 0;" class="value">${safeDate}</td>
        </tr>
        ${safeNotes ? `
        <tr>
          <td style="padding: 6px 0;" class="label">Merchant Note</td>
          <td style="padding: 6px 0;" class="value">${safeNotes}</td>
        </tr>` : ''}
      </table>

      ${safeUrl ? `
      <div style="text-align: center; margin: 28px 0;">
        <a href="${safeUrl}" class="btn">Pay Invoice via PayPal</a>
      </div>` : ''}

      <p style="font-size: 13px; color: #64748B;">
        Secure payment is processed through PayPal. You do not need a PayPal account to pay with a credit or debit card.
      </p>
    `
  });

  const text = `INVOICE READY FOR PAYMENT\n\nHello ${safeName},\n\nA new invoice ${safeInv} has been issued.\nDescription: ${safeDesc}\n${safeAmount ? `Total Due: ${safeAmount}\n` : ''}Date: ${safeDate}\n${safeNotes ? `Note: ${safeNotes}\n` : ''}\n${safeUrl ? `Pay securely online: ${safeUrl}\n\n` : ''}Thank you!`;

  return { subject, html, text };
}

/**
 * 4. Refund Update Email Template
 */
export function buildRefundIssuedTemplate({
  orderRef,
  customerName,
  amountDisplay,
  refundStatus = 'COMPLETED',
  timestamp
}) {
  const safeName = customerName ? escapeHtml(customerName) : 'Valued Customer';
  const safeRef = escapeHtml(orderRef);
  const safeAmount = escapeHtml(amountDisplay || '');
  const safeStatus = escapeHtml(refundStatus);
  const safeDate = escapeHtml(timestamp || new Date().toUTCString());

  const subject = `Refund Processed: Order ${safeRef}`;
  const previewText = `A refund has been processed for order ${safeRef}.`;

  const html = wrapLayout({
    title: subject,
    previewText,
    bodyContent: `
      <h1>Refund Confirmation</h1>
      <p>Hello ${safeName},</p>
      <p>This message confirms that a refund has been processed by PayPal for your order <strong>${safeRef}</strong>.</p>
      
      <table class="card" width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td style="padding: 6px 0;" class="label">Order Reference</td>
          <td style="padding: 6px 0;" class="value">${safeRef}</td>
        </tr>
        <tr>
          <td style="padding: 6px 0;" class="label">Refund Status</td>
          <td style="padding: 6px 0;" class="value"><span class="badge-success">${safeStatus}</span></td>
        </tr>
        ${safeAmount ? `
        <tr>
          <td style="padding: 6px 0;" class="label">Refund Amount</td>
          <td style="padding: 6px 0;" class="value">${safeAmount}</td>
        </tr>` : ''}
        <tr>
          <td style="padding: 6px 0;" class="label">Processed Date</td>
          <td style="padding: 6px 0;" class="value">${safeDate}</td>
        </tr>
      </table>

      <p>Depending on your card issuer or bank, the credit should appear on your statement within 3 to 7 business days.</p>
    `
  });

  const text = `REFUND CONFIRMATION\n\nHello ${safeName},\n\nA refund has been processed for order ${safeRef}.\nStatus: ${safeStatus}\n${safeAmount ? `Refund Amount: ${safeAmount}\n` : ''}Date: ${safeDate}\n\nFunds will credit to your original payment method.`;

  return { subject, html, text };
}

/**
 * 5. Order Status Update Email Template
 */
export function buildOrderStatusChangedTemplate({
  orderRef,
  customerName,
  newStatus,
  carrier,
  trackingNumber,
  trackingUrl,
  timestamp
}) {
  const safeName = customerName ? escapeHtml(customerName) : 'Valued Customer';
  const safeRef = escapeHtml(orderRef);
  const safeStatus = escapeHtml(newStatus || 'UPDATED');
  const safeCarrier = carrier ? escapeHtml(carrier) : null;
  const safeTrack = trackingNumber ? escapeHtml(trackingNumber) : null;
  const safeTrackUrl = trackingUrl ? escapeHtml(trackingUrl) : null;
  const safeDate = escapeHtml(timestamp || new Date().toUTCString());

  const subject = `Order Update: ${safeRef} is now ${safeStatus}`;
  const previewText = `Your order status has changed to ${safeStatus}.`;

  const html = wrapLayout({
    title: subject,
    previewText,
    bodyContent: `
      <h1>Order Status Update</h1>
      <p>Hello ${safeName},</p>
      <p>The status of your order <strong>${safeRef}</strong> has been updated.</p>
      
      <table class="card" width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td style="padding: 6px 0;" class="label">Order Reference</td>
          <td style="padding: 6px 0;" class="value">${safeRef}</td>
        </tr>
        <tr>
          <td style="padding: 6px 0;" class="label">New Status</td>
          <td style="padding: 6px 0;" class="value"><span class="badge-success">${safeStatus}</span></td>
        </tr>
        ${safeCarrier ? `
        <tr>
          <td style="padding: 6px 0;" class="label">Carrier</td>
          <td style="padding: 6px 0;" class="value">${safeCarrier}</td>
        </tr>` : ''}
        ${safeTrack ? `
        <tr>
          <td style="padding: 6px 0;" class="label">Tracking Number</td>
          <td style="padding: 6px 0;" class="value">${safeTrack}</td>
        </tr>` : ''}
        <tr>
          <td style="padding: 6px 0;" class="label">Update Timestamp</td>
          <td style="padding: 6px 0;" class="value">${safeDate}</td>
        </tr>
      </table>

      ${safeTrackUrl ? `
      <div style="text-align: center; margin: 24px 0;">
        <a href="${safeTrackUrl}" class="btn">Track Shipment</a>
      </div>` : ''}

      <p>Thank you for ordering with us. We will notify you of any further status changes.</p>
    `
  });

  const text = `ORDER STATUS UPDATE\n\nHello ${safeName},\n\nYour order ${safeRef} status is now: ${safeStatus}.\n${safeCarrier ? `Carrier: ${safeCarrier}\n` : ''}${safeTrack ? `Tracking: ${safeTrack}\n` : ''}Date: ${safeDate}\n\nThank you for choosing us!`;

  return { subject, html, text };
}

/**
 * 6. Send Payment Link Email Template
 * Dispatches an authentic PayPal Sandbox checkout link directly to customer.
 */
export function buildPaymentLinkTemplate({
  orderRef,
  recipientName,
  itemDescription,
  amountDisplay,
  checkoutUrl,
  timestamp
}) {
  const safeName = recipientName ? escapeHtml(recipientName) : 'Valued Customer';
  const safeRef = escapeHtml(orderRef);
  const safeDesc = escapeHtml(itemDescription || 'PayPal Order');
  const safeAmount = escapeHtml(amountDisplay || '');
  const safeUrl = checkoutUrl ? escapeHtml(checkoutUrl) : null;
  const safeDate = escapeHtml(timestamp || new Date().toUTCString());

  const subject = `Payment Request: Order ${safeRef}`;
  const previewText = `You have received a payment link for order ${safeRef}.`;

  const html = wrapLayout({
    title: subject,
    previewText,
    bodyContent: `
      <h1>Complete Your Payment</h1>
      <p>Hello ${safeName},</p>
      <p>A PayPal checkout link has been generated for your order <strong>${safeRef}</strong>. Click below to review and complete your payment securely on PayPal.</p>
      
      <table class="card" width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td style="padding: 6px 0;" class="label">Order Reference</td>
          <td style="padding: 6px 0;" class="value">${safeRef}</td>
        </tr>
        <tr>
          <td style="padding: 6px 0;" class="label">Description</td>
          <td style="padding: 6px 0;" class="value">${safeDesc}</td>
        </tr>
        ${safeAmount ? `
        <tr>
          <td style="padding: 6px 0;" class="label">Amount Due</td>
          <td style="padding: 6px 0;" class="value">${safeAmount}</td>
        </tr>` : ''}
        <tr>
          <td style="padding: 6px 0;" class="label">Issued Date</td>
          <td style="padding: 6px 0;" class="value">${safeDate}</td>
        </tr>
      </table>

      ${safeUrl ? `
      <div style="text-align: center; margin: 28px 0;">
        <a href="${safeUrl}" class="btn">Complete Payment on PayPal</a>
      </div>` : ''}

      <p style="font-size: 13px; color: #64748B;">
        This payment link was generated via PayPal Sandbox. You can pay securely with your PayPal account or a debit/credit card.
      </p>
    `
  });

  const text = `PAYMENT REQUEST\n\nHello ${safeName},\n\nA PayPal payment link has been generated for order ${safeRef}.\nDescription: ${safeDesc}\n${safeAmount ? `Amount Due: ${safeAmount}\n` : ''}Date: ${safeDate}\n\n${safeUrl ? `Complete your payment securely: ${safeUrl}\n\n` : ''}Thank you!`;

  return { subject, html, text };
}

export default {
  escapeHtml,
  buildPaymentCapturedTemplate,
  buildPaymentFailedTemplate,
  buildInvoiceCreatedTemplate,
  buildRefundIssuedTemplate,
  buildOrderStatusChangedTemplate,
  buildPaymentLinkTemplate
};
