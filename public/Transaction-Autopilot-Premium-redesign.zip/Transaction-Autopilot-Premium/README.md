# Transaction-Autopilot

> **Tagline:** Payment success doesn’t always mean commerce success.  
> **Hackathon Submission:** Built for the PayPal AI Hackathon.

---

## 1. Product Overview

Online merchants lose millions annually to a silent failure mode in modern eCommerce: **asynchronous decoupling between payment gateways and order fulfillment pipelines**. 

A buyer's PayPal payment is captured successfully, but downstream warehouse webhooks fail or inventory allocation locks stall the order. The merchant believes the transaction succeeded; the warehouse never receives the dispatch order; and the customer eventually files a chargeback dispute.

**Transaction Autopilot** is an AI-powered transaction reliability and recovery layer for PayPal-powered merchants. It autonomously detects cross-system inconsistencies between:
1. **PayPal Payment State** (`COMPLETED`, `AUTHORIZED`, `REFUNDED`)
2. **Merchant Store Order State** (`CREATED`, `PROCESSING`, `CANCELED`)
3. **Downstream Fulfillment State** (`DISPATCHED`, `IN_TRANSIT`, `NOT_DETECTED`)

When discrepancies arise, Transaction Autopilot:
- **Distinguishes Authoritative Facts from AI Hypotheses and Missing Information**.
- **Calculates Defensible Confidence Ratings**.
- **Recommends Ordered Safe Recovery Steps**.
- **Enforces Human-in-the-Loop Operator Sign-off** before executing sensitive financial or dispatch mutations.
- **Maintains an Immutable Audit Trail** of all automated and human decisions.

---

## 2. Technical Stack & Zero-Framework Philosophy

Per strict hackathon excellence guidelines, this application is built from scratch with zero framework overhead:

- **Markup**: Pure semantic HTML5 with accessible ARIA landmarks and native dialog elements.
- **Styling**: Modern CSS3 using CSS Custom Properties, CSS Grid, Flexbox, and Container queries.
- **Logic**: Vanilla JavaScript with ES Modules (`<script type="module">`). Zero React, Vue, Angular, or JSX.
- **Icons**: 100% scalable Lucide-style inline SVGs (strictly zero emojis used as UI icons).
- **Data Visualizations**: High-DPI Canvas 2D area charts and responsive SVG donut charts with zero external chart library bloat.
- **Design Intelligence**: Derived from the official **UI/UX Pro Max Skill** (`ui-ux-pro-max-skill`) with Visual Density 8/10 and Motion Intensity 3/10.

---

## 3. Flagship Demonstration Scenario

In the application's **AI Investigation Workspace** (`#investigations`), test the flagship scenario on transaction **`TRX-9042`**:

1. **PayPal State**: `$349.00 USD` captured and cleared into merchant account balance (Capture ID: `#CAP-982134`).
2. **Storefront State**: Shopify order `#ORD-84920` created for 2 items.
3. **Fulfillment State**: **`NOT DETECTED`** — Over 36 hours have elapsed with zero 3PL warehouse dispatch events or tracking numbers generated.
4. **AI Diagnosis**:
   - **Verified Facts**: Valid PayPal capture timestamp, store order existence, zero warehouse API events in 36h.
   - **Hypotheses**: 3PL webhook timeout during scheduled maintenance; inventory lock on SKU `#WH-9921`.
   - **Missing Information**: Distribution center WMS acknowledgement receipt.
   - **Confidence**: 94% with explicit defensible rationale.
5. **Safe Recovery Action**:
   - Operator clicks **"Review in Approval Queue"**.
   - Review the risk impact in the **Approval Queue** (`#approvals`).
   - Approve the re-dispatch action with an operator note.
   - Watch the simulated state update to `DISPATCH_QUEUED` and an entry instantly append to the **Audit Log** (`#audit`).

---

## 4. Setup & Running Locally

Because this application utilizes modern Vanilla JavaScript ES Modules, it must be served via a local web server rather than opened directly as `file://`.

### Option A: Using Python (Installed on most systems)
```bash
cd Transaction-Autopilot
python -m http.server 8080
```
Open [http://localhost:8080](http://localhost:8080) in your browser.

### Option B: Using Node.js
```bash
cd Transaction-Autopilot
node -e "const http=require('http'),fs=require('fs'),path=require('path');http.createServer((req,res)=>{const f=path.join('.',req.url==='/'?'index.html':req.url);fs.readFile(f,(e,d)=>{if(e){res.writeHead(404);return res.end('Not found');}const ext=path.extname(f);const ct=ext==='.js'?'text/javascript':ext==='.css'?'text/css':ext==='.html'?'text/html':'application/octet-stream';res.writeHead(200,{'Content-Type':ct});res.end(d);});}).listen(8080,()=>console.log('Server running at http://localhost:8080'));"
```

### Option C: Using any Static Server (npx serve / live-server)
```bash
npx serve .
```

---

## 5. Verification & Automated Test Suite

A standalone headless verification test runner is included in `tests/test-runner.js`:

```bash
node tests/test-runner.js
```

This verifies:
1. Parsing of all demo transaction records without schema errors.
2. Accurate mathematical calculation of dashboard KPI totals and healthy rates.
3. Reactive state mutations upon operator approvals and rejections.
4. Synchronous appending to the immutable audit log.

---

## 6. Under-3-Minute Video Demonstration Script

- **0:00 - 0:30 (The Problem)**: Explain that payment success doesn’t guarantee commerce success. Show PayPal capture succeeded, but orders get lost in warehouse limbo.
- **0:30 - 1:10 (The Overview Dashboard)**: Tour the mission control overview, showing 24h volume, pipeline health donut, and the Critical Discrepancy banner.
- **1:10 - 1:55 (The AI Investigation Workspace)**: Click into transaction `TRX-9042`. Showcase the 3-Way Reconciliation Matrix, the Event Timeline, and the AI diagnosis explicitly distinguishing verified facts from hypotheses.
- **1:55 - 2:30 (Human Approval & Audit Trail)**: Queue the recovery re-dispatch, navigate to the Approval Queue, provide an operator note, confirm execution, and show the immutable entry in the Audit Log.
- **2:30 - 3:00 (Architecture & Conclusion)**: Highlight the zero-framework pure web architecture, UI/UX Pro Max tokens, and clear path to production PayPal REST API integration.

---

## 7. Open Source License

This project is licensed under the open-source **MIT License** — see the [LICENSE](LICENSE) file for details.
